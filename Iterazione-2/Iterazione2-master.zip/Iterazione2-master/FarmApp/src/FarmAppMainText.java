import interfaccia.FarmAppConsole;

public class FarmAppMainText {
	
	public static void main(String[] args) throws Exception {
		FarmAppConsole fa = new FarmAppConsole();
		fa.start();
	}
}
