package interfaccia;

import java.io.*;

class Parser {
	private ElencoComandi comandi;
	private static Parser singleton;
	
    public Parser() {
        comandi = new ElencoComandi();
    }

	public static Parser getInstance() {
		if (singleton==null)
			singleton=new Parser();
		return singleton;
	}

    public String read() {
        String inputLine = "";

        System.out.print(" > ");
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        try {
            inputLine = reader.readLine();
        }
        catch(java.io.IOException exc) {
            System.out.println ("Errore durante la lettura: " + exc.getMessage());
        }
		return inputLine;
    }
		
    public Comando getComando(int console) {
        String parola = read();
		Comando comando = null;
		
		if(comandi.comandoValido(parola,console)) {
			/* CONSOLE PRINCIPALE */
			if (console == ElencoComandi.FarmApp){
				if (parola.equals("1"))
					comando = new ComandoRegistrazioneNuovoCliente();
				if (parola.equals("2"))
					comando = new ComandoGestioneProdotti();
				if (parola.equals("3"))
					comando = new ComandoInserisciNuovoOrdine();
				if (parola.equals("4"))
					comando = new ComandoAssociaCartaCredito();
				if (parola.equals("5"))
					comando = new ComandoVisualizzazioneInventario();
				if (parola.equals("6"))
					comando = new ComandoRitiroOrdine();
			}
			/* CONSOLE REGISTRAZIONE_NUOVO_CLIENTE */
			if (console == ElencoComandi.REGISTRAZIONE_NUOVO_CLIENTE){
				if (parola.equals("1"))
					comando = new ComandoRegistrazioneCliente();
				if (parola.equals("2"))
					comando = new ComandoConfermaRegistrazione();
			}
			/* CONSOLE GESTIONE_PRODOTTI */
			if (console == ElencoComandi.GESTIONE_PRODOTTI){
				if (parola.equals("1"))
					comando = new ComandoNuovoFarmaco();
				if (parola.equals("2"))
					comando = new ComandoConfermaFarmaco();
			}
			/* INSERISCI_NUOVO_ORDINE  */
			if (console == ElencoComandi.INSERISCI_NUOVO_ORDINE){
				if (parola.equals("1"))
					comando = new ComandoNuovoOrdine();
				if (parola.equals("2"))
					comando = new ComandoAggiungiFarmaco();
				if (parola.equals("3"))
					comando = new ComandoConfermaOrdine();
				if (parola.equals("4"))
					comando = new ComandoConsulenza();
			}
			/* ASSOCIA_CARTA_CREDITO  */
			if (console == ElencoComandi.ASSOCIA_CARTA_CREDITO){
				if (parola.equals("1"))
					comando = new ComandoInserisciDatiCarta();
				if (parola.equals("2"))
					comando = new ComandoConfermaDatiCarta();
			}
			/* VISUALIZZA_INVENTARIO  */
			if (console == ElencoComandi.VISUALIZZA_INVENTARIO){
				if (parola.equals("1"))
					comando = new ComandoVisualizzaInventario();
				if (parola.equals("2"))
					comando = new ComandoSelezionaFarmaco();
				}
			
			/* RITIRO_ORDINE  */
			if (console == ElencoComandi.RITIRO_ORDINE){
				if (parola.equals("1"))
					comando = new ComandoInserisciDatiCliente();
				if (parola.equals("2"))
					comando = new ComandoConvalidaPrescrizione();
				if (parola.equals("3"))
					comando = new ComandoConvalidaOrdine();
				}	
			
			/* TORNA AL MENU' PRECEDENTE O ESCI */
			if (parola.equals("0"))
				comando = new ComandoEsci();
	   } else comando = new ComandoNonValido();
		
       return comando;
    }
}
