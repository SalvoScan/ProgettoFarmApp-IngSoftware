package interfaccia;

import dominio.*;
import java.util.*;

public class ComandoConvalidaOrdine implements Comando {
	public static final String codiceComando = "3";
	public static final String descrizioneComando = "Convalida ordine";
	
	public String getCodiceComando() {
		return this.codiceComando;
	}
	
	public String getDescrizioneComando() {
		return this.descrizioneComando;
	}
	
	public void esegui(FarmApp fapp) {
		OrdinePrenotato ordine_corrente = fapp.getOrdinePrenotatoCorrente();
		boolean pagato = ordine_corrente.getPagato();
		OrdineConsegnato ordine_consegnato = new OrdineConsegnato(ordine_corrente);
		
		for(Cliente c : fapp.getListaClienti()) {
			if(c.getId() == fapp.getClienteAlBanco().getId()) {
				c.setOrdiniConsegnati(ordine_consegnato);
				c.setOrdinePrenotato(null);
			}
		}
		System.out.println("L'ordine � stato aggiunto");
		
		//AGGIORNAMENTO INVENTARIO
		List<Farmaco> farmaci = fapp.getInventario().getListaFarmaci();
		for(Farmaco f : farmaci) {
			for(Farmaco far : ordine_corrente.getFarmaciOrdinati()) {
					if(f.getNumSerie().equals(far.getNumSerie())) {
						f.setQuantita(f.getQuantita() - far.getQuantita());
					}
			}			
		}
		fapp.getInventario().setListaFarmaci(farmaci);
		//COLLEGARE AL CASO D'USO VENDITA SE L'ORDINE NON � STATO PAGATO
		System.out.println("L'ordine � stato aggiunto");
	}
}
