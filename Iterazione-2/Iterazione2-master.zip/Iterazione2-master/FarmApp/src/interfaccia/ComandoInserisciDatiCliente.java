package interfaccia;

import java.util.List;

import dominio.*;

public class ComandoInserisciDatiCliente implements Comando {
	public static final String codiceComando = "1";
	public static final String descrizioneComando = "Inserimento dati cliente";
	
	public String getCodiceComando() {
		return this.codiceComando;
	}
	
	public String getDescrizioneComando() {
		return this.descrizioneComando;
	}
	
	public void esegui(FarmApp fapp) {
		System.out.println("Inserisci codice fiscale del cliente");
		String cf = Parser.getInstance().read();
		List<Cliente> clienti = fapp.getListaClienti();
		for(Cliente c : clienti) {
			if(c.getAccount().getCodiceFiscale().equals(cf)) {
				fapp.setClienteAlBanco(c);
				if(c.getOrdinePrenotato() != null) {
					System.out.println(c.getOrdinePrenotato());
					fapp.setOrdinePrenotatoCorrente(c.getOrdinePrenotato());
					if(c.getOrdinePrenotato().getPagato()) {
						System.out.println("L'ordine � stato pagato");
						return;
					}
					else {
						System.out.println("L'ordine non � stato pagato");
						return;
					}
				}
				else {
					System.out.println("Non esiste alcun ordine prenotato");
					return;
				}
			}
		}
			System.out.println("Non esiste cliente con questo codice fiscale");
	}
}
