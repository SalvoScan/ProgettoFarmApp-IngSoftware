package interfaccia;

public class ElencoComandi {
	public static final int FarmApp = 0;
	public static final int REGISTRAZIONE_NUOVO_CLIENTE= 1;
	public static final int GESTIONE_PRODOTTI = 2;
	public static final int INSERISCI_NUOVO_ORDINE = 3;
	public static final int ASSOCIA_CARTA_CREDITO = 4;
	public static final int VISUALIZZA_INVENTARIO = 5;
	public static final int RITIRO_ORDINE = 6;
	
	/*MENU' INIZIALE*/
    private static final String comandiValidiFarmAppConsole[][] = {
		{ComandoRegistrazioneNuovoCliente.codiceComando,ComandoRegistrazioneNuovoCliente.descrizioneComando},
		{ComandoGestioneProdotti.codiceComando,ComandoGestioneProdotti.descrizioneComando},
		{ComandoInserisciNuovoOrdine.codiceComando,ComandoInserisciNuovoOrdine.descrizioneComando},
		{ComandoAssociaCartaCredito.codiceComando, ComandoAssociaCartaCredito.descrizioneComando},
		{ComandoVisualizzazioneInventario.codiceComando, ComandoVisualizzazioneInventario.descrizioneComando},
		{ComandoRitiroOrdine.codiceComando, ComandoRitiroOrdine.descrizioneComando},
		{ComandoEsci.codiceComando, ComandoEsci.descrizioneComando}
    };
    
    /* USE CASE 1 : REGISTRAZIONE_NUOVO_CLIENTE */
	private static final String comandiValidiRegistrazioneNuovoCliente[][] = {
		{ComandoRegistrazioneCliente.codiceComando, ComandoRegistrazioneCliente.descrizioneComando},
		{ComandoConfermaRegistrazione.codiceComando, ComandoConfermaRegistrazione.descrizioneComando},
		{ComandoEsci.codiceComando, ComandoEsci.descrizioneComando}
	};
	
	/* USE CASE 2 : GESTIONE_PRODOTTI */
	private static final String comandiValidiGestioneProdotti[][] = {
		{ComandoNuovoFarmaco.codiceComando, ComandoNuovoFarmaco.descrizioneComando},
		{ComandoConfermaFarmaco.codiceComando, ComandoConfermaFarmaco.descrizioneComando},
		{ComandoEsci.codiceComando, ComandoEsci.descrizioneComando}
	};
	
	/* USE CASE 3 : INSERISCI_NUOVO_ORDINE */
	private static final String comandiValidiInserisciNuovoOrdine[][] = {
		{ComandoNuovoOrdine.codiceComando, ComandoNuovoOrdine.descrizioneComando},
		{ComandoAggiungiFarmaco.codiceComando, ComandoAggiungiFarmaco.descrizioneComando},
		{ComandoConfermaOrdine.codiceComando, ComandoConfermaOrdine.descrizioneComando},
		{ComandoConsulenza.codiceComando, ComandoConsulenza.descrizioneComando},
		{ComandoEsci.codiceComando, ComandoEsci.descrizioneComando}
	};
	
	/* USE CASE 4 : ASSOCIA_CARTA_CREDITO */
	private static final String comandiValidiAssociaCartaCredito[][] = {
		{ComandoInserisciDatiCarta.codiceComando, ComandoInserisciDatiCarta.descrizioneComando},
		{ComandoConfermaDatiCarta.codiceComando, ComandoConfermaDatiCarta.descrizioneComando},
		{ComandoEsci.codiceComando, ComandoEsci.descrizioneComando}
	};
	
	/* USE CASE 5 : VISUALIZZA_INVENTARIO */
	private static final String comandiValidiVisualizzaInventario[][] = {
		{ComandoVisualizzaInventario.codiceComando, ComandoVisualizzaInventario.descrizioneComando},
		{ComandoSelezionaFarmaco.codiceComando, ComandoSelezionaFarmaco.descrizioneComando},
		{ComandoEsci.codiceComando, ComandoEsci.descrizioneComando}
	};
	
	/* USE CASE 6 : RITIRO_ORDINE */
	private static final String comandiValidiRitiroOrdine[][] = {
		{ComandoInserisciDatiCliente.codiceComando, ComandoInserisciDatiCliente.descrizioneComando},
		{ComandoConvalidaPrescrizione.codiceComando, ComandoConvalidaPrescrizione.descrizioneComando},
		{ComandoConvalidaOrdine.codiceComando, ComandoConvalidaOrdine.descrizioneComando},
		{ComandoEsci.codiceComando, ComandoEsci.descrizioneComando}
	};
	
	public static String elencoTuttiComandi(int console){
    	int i=0;
    	StringBuffer elenco = new StringBuffer();
		String comandi[][]=getComandi(console);
		
		
    	for (i=0; i<comandi.length-1; i++) {
			elenco.append(comando(i,console));
			elenco.append("\n");
		}
		elenco.append(comando(i,console));
		return elenco.toString();
    }
	
	private static String comando(int i, int console) {
		String comandi[][]= getComandi(console);
		return " " + comandi[i][0] + ")" + comandi[i][1];
	}

	public static String[][] getComandi(int console){
		
		String comandi[][]=null;
		
		switch (console){
			case FarmApp: comandi = comandiValidiFarmAppConsole; break;
			case REGISTRAZIONE_NUOVO_CLIENTE: comandi = comandiValidiRegistrazioneNuovoCliente; break;
			case GESTIONE_PRODOTTI: comandi = comandiValidiGestioneProdotti; break;
			case INSERISCI_NUOVO_ORDINE: comandi = comandiValidiInserisciNuovoOrdine; break;
			case ASSOCIA_CARTA_CREDITO: comandi = comandiValidiAssociaCartaCredito; break;
			case VISUALIZZA_INVENTARIO: comandi = comandiValidiVisualizzaInventario; break;
			case RITIRO_ORDINE: comandi = comandiValidiRitiroOrdine; break;
		};
		return comandi;
	}
	
    public boolean comandoValido(String stringa, int console) {
		String comandi[][]= getComandi(console);
		for(int i = 0; i < comandi.length; i++) {
            if(comandi[i][0].equals(stringa))
                return true;
        }
        return false;
    }
	
}
