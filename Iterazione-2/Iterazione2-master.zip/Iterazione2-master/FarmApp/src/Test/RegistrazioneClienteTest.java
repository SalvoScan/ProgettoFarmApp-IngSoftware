package Test;

import dominio.*;
import interfaccia.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RegistrazioneClienteTest {
	
	FarmApp fapp = new FarmApp();

	@Test //Testiamo se il cliente aggiunto venga aggiunto correttamente alla lista dei clienti
	void testRegistrazioneCliente() {
		String email = "nunzio@live.it";
		String password = "123456";
		Account a = new Account("nunzio", "saitta", "19-10-1997", "sttnnz97r19b202q", "via fusco");
		Cliente c = new Cliente(email, password, a);
		
		int numero_clienti = fapp.getListaClienti().size();
		fapp.setNuovoCliente(c);
		
		
		assertEquals("nunzio@live.it", fapp.getListaClienti().get(numero_clienti).getEmail());
	}

}
