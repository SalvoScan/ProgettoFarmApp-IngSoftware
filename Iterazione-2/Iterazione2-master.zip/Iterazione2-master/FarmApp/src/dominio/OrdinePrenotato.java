package dominio;

import java.util.Date;
import java.util.List;

public class OrdinePrenotato extends Ordine{
	private boolean pagato = false;	
	
	public OrdinePrenotato(Ordine ordine) {
		super(ordine.getCodOrdine(), ordine.getPrezzoOrdine(), ordine.getOrarioOrdine(), ordine.getOrarioRitiro(), ordine.getFarmaciOrdinati());
	}

	public boolean getPagato() {
		return pagato;
	}

	public void setPagato(boolean pagato) {
		this.pagato = pagato;
	}
	
	
}
