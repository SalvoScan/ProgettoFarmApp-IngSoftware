package dominio;

import java.util.Date;
import java.util.List;

public class OrdineConsegnato extends OrdinePrenotato{

	public OrdineConsegnato(OrdinePrenotato ordine) {
		super(ordine);
	}

	
}
