package dominio;

public class Amministratore {
	/*mmmmmmmm */
}
