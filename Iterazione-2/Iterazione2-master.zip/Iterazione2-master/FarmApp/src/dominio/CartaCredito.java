package dominio;

import java.text.SimpleDateFormat;
import java.util.*;

public class CartaCredito {
	private long cod_IBAN;
	private Date scadenza;
	private String nome_intestatario;
	private String cognome_intestatario;
	
	//Costruttore
	
	public CartaCredito(long cod_IBAN, Date scadenza, String nome_intestatario, String cognome_intestatario) {
		setCodIBAN(cod_IBAN);
		setScadenza(scadenza);
		setNomeIntestatario(nome_intestatario);
		setCognomeIntestatario(cognome_intestatario);
	}
	
	//Metodi GETTER
	
	public long getCodIBAN() {
		return this.cod_IBAN;
	}
	
	public String getScadenza() {
		SimpleDateFormat formato_data = new SimpleDateFormat ("dd.MM.yyyy");
		String scad = formato_data.format(this.scadenza);
		return scad;
	}
	
	public String getNomeIntestatario() {
		return this.nome_intestatario;
	}
	
	public String getCognomeIntestatario() {
		return this.cognome_intestatario;
	}
	
	//Metodi SETTER
	
	public void setCodIBAN(long cod_IBAN) {
		this.cod_IBAN = cod_IBAN;
	}
	
	public void setScadenza(Date scadenza) {
		this.scadenza = scadenza;
	}
	
	public void setNomeIntestatario(String nome_intestatario) {
		this.nome_intestatario = nome_intestatario;
	}
	
	public void setCognomeIntestatario(String cognome_intestatario) {
		this.cognome_intestatario = cognome_intestatario;
	}
	
	//Metodo toString
	
	public String toString() {
		String s1 = "INFO CARTA DI CREDITO\n";
		String s2 = "Cod IBAN : "+getCodIBAN()+"\n"+"Scadenza carta di credito : "+getScadenza()+"\n";
		String s3 = "Nome Intestatario : "+getNomeIntestatario()+"\n"+"Cognome Intestatario : "+getCognomeIntestatario();
		String s = s1 + s2 + s3;
		
		return s;
	}
	
	//Metodo Confronta
	
	public boolean confronta(long cod_IBAN) {
		if(this.cod_IBAN == cod_IBAN) {
			//I codici IBAN sono uguali
			return true;
		}else {
			//I codici IBAN sono diversi
			return false;
		}
	}
}
