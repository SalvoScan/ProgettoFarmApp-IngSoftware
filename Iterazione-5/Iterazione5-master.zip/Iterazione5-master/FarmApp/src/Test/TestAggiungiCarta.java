package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import dominio.*;


import org.junit.jupiter.api.Test;

class TestAggiungiCarta {
	FarmApp fapp = new FarmApp();

	@Test
	void testAggiungiCarta() {
		//Account a1 = new Account("salvo", "scandura", "30-02-2020", "sssssssss", "via tomarchi");
		Cliente c = fapp.getListaClienti().get(0);
		Account a = c.getAccount();
		
		try {
			String scadenza = "08.10.2030";
			SimpleDateFormat formato_data2 = new SimpleDateFormat ("dd.MM.yyyy");
			Date sc = new Date();
			sc = formato_data2.parse(scadenza);
			CartaCredito cc1 = new CartaCredito(54329, sc, "orazio", "ubeddu");
			a.setCartaCredito(cc1);
		}catch(ParseException e) {
			System.out.println("ParseException occured: " + e.getMessage());
		}
		
		assertEquals("08.10.2030", a.getCartaCredito().getScadenza());
	}

}
