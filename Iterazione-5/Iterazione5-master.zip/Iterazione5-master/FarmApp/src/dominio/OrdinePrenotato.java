package dominio;

public class OrdinePrenotato extends Decoratore{
	private boolean pagato;
	private int id_cliente;
	
	public OrdinePrenotato(Ordine ordine) {
		super(ordine);
		pagato = false;
	}
	
	public OrdinePrenotato(OrdinePrenotato ordine) {
		super(ordine.getOrdine());
	}

	public boolean getPagato() {
		return pagato;
	}
	
	public int getIdCliente() {
		return id_cliente;
	}
	
	public void setPagato(boolean pagato) {
		this.pagato = pagato;
	}
	
	public void setIdCliente(int id_cliente) {
		this.id_cliente = id_cliente;
	}
	
	
}
