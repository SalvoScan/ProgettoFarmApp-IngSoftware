package dominio;

public class OrdineConsegnato extends OrdinePrenotato implements SubjectInferfaccia{
	private int metodo;
	RegistroVendite registro_vendite;

	public OrdineConsegnato(OrdinePrenotato ordine) {
		super(ordine);	
	}
	
	public int getMetodo() {
		return metodo;
	}
	
	public void setMetodo(int metodo) {
		this.metodo = metodo;
	}
	
	// Metodi dell'interfaccia
	public void addObserver(RegistroVendite rv) {
		this.registro_vendite = rv;
	}
	
	public void removeObserver() {
		this.registro_vendite = null;
	}
	
	public void notifyObserver() {
		this.registro_vendite.update(this);
	}
	
	@Override
	public void setPagato(boolean pagato) {
		super.setPagato(pagato);
		notifyObserver();
	}
}
