package interfaccia;

import java.text.*;
import java.util.*;
import dominio.*;

public class ComandoConsulenza implements Comando{
	public static final String codiceComando = "4";
	public static final String descrizioneComando = "Richiedi consulenza";
	
	public String getCodiceComando() {
		return codiceComando;
	}

	public String getDescrizioneComando() {
		return descrizioneComando;
	}
	
	public void esegui(FarmApp farmapp) {
		Cliente cl_autenticato = farmapp.getClienteAutenticato();
		GregorianCalendar gc = new GregorianCalendar();
		Date data_ordine = new Date();
		Date data_ritiro = new Date();
    	List<String> orari = farmapp.getListaOrari();
		long anno = gc.get(Calendar.YEAR);
		long mese = gc.get(Calendar.MONTH) + 1;
		long giorno = gc.get(Calendar.DATE);
		long ora_ordine = gc.get(Calendar.HOUR_OF_DAY);
	    long ora_ritiro = gc.get(Calendar.HOUR_OF_DAY) + 3;
		long min = gc.get(Calendar.MINUTE);
    	gc.add((Calendar.DATE), 1);
        long domani = gc.get(Calendar.DATE);
        
		if(cl_autenticato.getOrdinePrenotato() != null) {
			System.out.println("Esiste gi� una prenotazione attualmente in corso!");
			return;
		}
		
	    String s_data = String.valueOf(giorno) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + String.valueOf(ora_ordine) + ":" + String.valueOf(min);
	    String s_data1;
	    try{
	        data_ordine = new SimpleDateFormat("dd-MM-yyyy hh:mm").parse(s_data);
	        
	        if(ora_ordine >= 7 && ora_ordine <= 18){
	        	//Gestire orario 12 (viene visualizzato 00 in ora_ordine)
                s_data1 = String.valueOf(giorno) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + String.valueOf(ora_ritiro) + ":" + String.valueOf(min);
            }
	        else {
                s_data1 = String.valueOf(domani) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + orari.get(0);
            }
	        
	        data_ritiro = new SimpleDateFormat("dd-MM-yyyy hh:mm").parse(s_data1);
	        System.out.println("La data e l'ora della consulenza e': " + data_ritiro);
	        System.out.println("Confermare tale orario? Y/N");
	        String scelta = Parser.getInstance().read();
	        
	        if(scelta.equals("N")) {
	        	System.out.println("Scegli un orario tra quelli disponibili");
	        	System.out.println(orari.toString());
	        	System.out.println("Scrivi l'orario desiderato (formato hh:mm):");
	        	String scelta_orario = Parser.getInstance().read();
	        	int check = 0;
	        	for(String orari_disp : orari) {
	        		check = check + 1;
	        		if(scelta_orario.equals(orari_disp)) {
	        			farmapp.setListaOrari(scelta_orario);
	        			s_data1 = String.valueOf(domani) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + scelta_orario;
	        			data_ritiro = new SimpleDateFormat("dd-MM-yyyy hh:mm").parse(s_data1);
	        			break;
	        		}
	        		if(orari.size() == check) {
	        			System.out.println("Orario errato!");
	        			return;
	        		}
	        	}	
	        }
	    } catch (ParseException e) {
	    System.out.println("Orario errato!");
	    return;
	    }
	    
	    int cod_ordine = 0;
	    for(Cliente c : farmapp.getListaClienti()) {
	    	if(c.getId() == cl_autenticato.getId()) {
	    		cod_ordine = c.getOrdiniConsegnati().size() + 1;
	    	}
	    }
	    
		OrdineConsulenza ordine_corrente = new OrdineConsulenza(cod_ordine, 15, data_ordine, data_ritiro, null);
		OrdinePrenotato ordine_prenotato = new OrdinePrenotato(ordine_corrente);
		farmapp.getClienteAutenticato().setOrdinePrenotato(ordine_prenotato);
		for(Cliente c : farmapp.getListaClienti()) {
			if(c.getId() == farmapp.getClienteAutenticato().getId()) {
				c.setOrdinePrenotato(ordine_prenotato);
			}
		}
		farmapp.setPrezzoOrdineCorrente(0);
		System.out.println("Consulenza confermata!");
	}
}
