package interfaccia;

import java.util.List;

import dominio.*;

public class ComandoIdentificaCliente implements Comando {
	public static final String codiceComando = "1";
	public static final String descrizioneComando = "Inserisci il codice fiscale";
	
	public String getCodiceComando() {
		return codiceComando;
	}

	public String getDescrizioneComando() {
		return descrizioneComando;
	}

	
	public void esegui(FarmApp fapp) throws Exception {
		List<Cliente> lista_clienti = fapp.getListaClienti();
		System.out.println("Inserisci codice fiscale del cliente:");
		String cod_fiscale = Parser.getInstance().read();
		
		for (Cliente c : lista_clienti) {
			if (cod_fiscale.equals(c.getAccount().getCodiceFiscale())) {
				fapp.setClienteConsulenza(c);
				System.out.println("Cliente autenticato...");
				
				OrdinePrenotato op = c.getOrdinePrenotato();
				Ordine o = op.getOrdine();
				if(o.getClass() == OrdineConsulenza.class) {
					System.out.println("MMMMMMMMMMMMMMMM");
					System.out.println(o);
					return;
				}else {
					System.out.println("Il Cliente non possiede alcun ordine consulenza");
					return;
				}
				
			}	
		}
		System.out.println("Il Cliente non � stato autenticato");
	}

}
