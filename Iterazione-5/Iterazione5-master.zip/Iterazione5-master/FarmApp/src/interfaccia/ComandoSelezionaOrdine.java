package interfaccia;

import java.util.List;

import dominio.*;

public class ComandoSelezionaOrdine implements Comando{
	public static final String codiceComando = "2";
	public static final String descrizioneComando = "Seleziona ordine";
	
	public String getCodiceComando() {
		return codiceComando;
	}
	
	public String getDescrizioneComando() {
		return descrizioneComando;
	}
	
	public void esegui(FarmApp farmapp) {
		Cliente cl_autenticato = farmapp.getClienteAutenticato();
		List<OrdineConsegnato> storico_ordini = cl_autenticato.getOrdiniConsegnati();
		System.out.println("Inserisci il codice dell'ordine: ");
		String c_ordine = Parser.getInstance().read();
		int cod_ordine = Integer.parseInt(c_ordine);
		for(OrdineConsegnato oc : storico_ordini) {
			if(oc.getCodOrdine() == cod_ordine) {
				OrdineConsegnato ordine_selezionato = new OrdineConsegnato(oc);
				farmapp.setOrdineSelezionato(ordine_selezionato);
				System.out.println(ordine_selezionato.toString());
				return;
			}
		}
		System.out.println("Codice errato!");
	}
}
