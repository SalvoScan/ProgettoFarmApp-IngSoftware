package interfaccia;

import dominio.*;

public class ComandoConfermaConsulenza implements Comando {
	public static final String codiceComando = "3";
	public static final String descrizioneComando = "Conferma consulenza";

	public String getCodiceComando() {
		return codiceComando;
	}

	public String getDescrizioneComando() {
		return descrizioneComando;
	}

	public void esegui(FarmApp fapp) throws Exception {
		Cliente cc = fapp.getClienteConsulenza();
		OrdinePrenotato op = new OrdinePrenotato(cc.getOrdinePrenotato());
		fapp.setNuovoOrdine(op);
		
		System.out.println(op);
		System.out.println("Operazione Consulenza Terminata");
	}

}
