package interfaccia;

import dominio.*;
import java.util.*;

public class ComandoNuovoFarmaco implements Comando{
	public static final String codiceComando = "1";
	public static final String descrizioneComando = "Inserimento nuovo farmaco";
	
	public String getCodiceComando() {
		return codiceComando;
	}
	
	public String getDescrizioneComando() {
		return descrizioneComando;
	}
	
	public void esegui(FarmApp fapp) {
		System.out.println("Inserisci numero di serie");
		String num_serie = Parser.getInstance().read();
		System.out.println("Inserisci quantita del farmaco");
		String quantita = Parser.getInstance().read();
		int q = Integer.parseInt(quantita);
		
		Inventario i = fapp.getInventario();
		List<DescrizioneFarmaco> ldf = i.getListaDescrizioniFarmaci();
		List<Farmaco> lf = i.getListaFarmaci();
		
		DescrizioneFarmaco df = null;
		Farmaco farmaco = null;
		
		int quant = 0;
		
		for(DescrizioneFarmaco descr : ldf) {
			if(num_serie.equals(descr.getNumSerie())) {
				for(Farmaco f : lf) {
					if(num_serie.equals(f.getNumSerie())) {
						if(q >= 0) {
							quant = q + f.getQuantita();
							df = descr;
							farmaco = new Farmaco(num_serie, quant, df);
							//Riepilogo INFO
							System.out.println(farmaco);
							fapp.setFarmacoCorrente(farmaco);
							return;
						}else {
							quant = f.getQuantita() + q;
							if(quant < 0) {
								quant = 0;
							}
							df = descr;
							farmaco = new Farmaco(num_serie, quant, df);
							//Riepilogo INFO
							System.out.println(farmaco);
							fapp.setFarmacoCorrente(farmaco);
							return;
						}
					}
				}
				
				df = descr;
				farmaco = new Farmaco(num_serie, q, df);
				//Riepilogo INFO
				System.out.println(farmaco);
				fapp.setFarmacoCorrente(farmaco);
				return;
			}
		}
		System.out.println("Farmaco non trovato");
		
	}
	
	
}
