package interfaccia;

import java.io.*;

class Parser {
	private ElencoComandi comandi;
    private boolean check = false;
	private static Parser singleton;
	
    public Parser() {
        comandi = new ElencoComandi();
    }

	public static Parser getInstance() {
		if (singleton==null)
			singleton=new Parser();
		return singleton;
	}

    public String read() {
        String inputLine = "";

        System.out.print(" > ");
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        try {
            inputLine = reader.readLine();
        }
        catch(java.io.IOException exc) {
            System.out.println ("Errore durante la lettura: " + exc.getMessage());
        }
		return inputLine;
    }
		
    public Comando getComando(int console) {

        String parola = read();

		Comando comando = null;
		
		
		
		if(comandi.comandoValido(parola,console)) {
			/* CONSOLE PRINCIPALE */
			if (console == ElencoComandi.FarmApp){
				
				
				if (parola.equals("1")) {
					if(ElencoComandi.mod == 1) {
						comando = new ComandoGestioneProdotti();
					}else if(ElencoComandi.mod == 2) {
						comando = new ComandoRitiroOrdine();
					}else if(ElencoComandi.mod == 3) {
						comando = new ComandoGestioneOrdineDomicilio();
					}else if(ElencoComandi.mod == 4) {
						comando = new ComandoRegistrazioneNuovoCliente();
					}
				}
				if (parola.equals("2")) {
					if(ElencoComandi.mod == 1) {
						comando = new ComandoRegistroVendite();
					}else if(ElencoComandi.mod == 2) {
						comando = new ComandoRegistrazioneOrdineConsulenza();
					}else if(ElencoComandi.mod == 3) {
						comando = new ComandoNonValido();
					}else if(ElencoComandi.mod == 4) {
						comando = new ComandoInserisciNuovoOrdine();
					}
				}
				if (parola.equals("3")) {
					if(ElencoComandi.mod == 1) {
						comando = new ComandoNonValido();
					}else if(ElencoComandi.mod == 2) {
						comando = new ComandoNonValido();
					}else if(ElencoComandi.mod == 3) {
						comando = new ComandoNonValido();
					}else if(ElencoComandi.mod == 4) {
						comando = new ComandoAssociaCartaCredito();
					}
				}
				if(parola.equals("4") && ElencoComandi.mod == 4) {
					comando = new ComandoVisualizzazioneInventario();
				}else if(parola.equals("4") && ElencoComandi.mod != 4) {
					comando = new ComandoNonValido();
				}
				if(parola.equals("5") && ElencoComandi.mod == 4) {
					comando = new ComandoVisualizzaStoricoOrdini();
				}else if(parola.equals("5") && ElencoComandi.mod != 4) {
					comando = new ComandoNonValido();
				}
				if(Integer.parseInt(parola) > 5 || Integer.parseInt(parola) < 0) {
					comando = new ComandoNonValido();
				}
				
			}
			/* CONSOLE REGISTRAZIONE_NUOVO_CLIENTE */
			if (console == ElencoComandi.REGISTRAZIONE_NUOVO_CLIENTE){
				if (parola.equals("1"))
					comando = new ComandoRegistrazioneCliente();
				if (parola.equals("2"))
					comando = new ComandoConfermaRegistrazione();
			}
			/* CONSOLE GESTIONE_PRODOTTI */
			if (console == ElencoComandi.GESTIONE_PRODOTTI){
				if (parola.equals("1"))
					comando = new ComandoNuovoFarmaco();
				if (parola.equals("2"))
					comando = new ComandoConfermaFarmaco();
			}
			/* INSERISCI_NUOVO_ORDINE  */
			if (console == ElencoComandi.INSERISCI_NUOVO_ORDINE){
				if (parola.equals("1"))
					comando = new ComandoNuovoOrdine();
				if (parola.equals("2"))
					comando = new ComandoAggiungiFarmaco();
				if (parola.equals("3"))
					comando = new ComandoConfermaOrdine();
				if (parola.equals("4"))
					comando = new ComandoConsulenza();
			}
			/* ASSOCIA_CARTA_CREDITO  */
			if (console == ElencoComandi.ASSOCIA_CARTA_CREDITO){
				if (parola.equals("1"))
					comando = new ComandoInserisciDatiCarta();
				if (parola.equals("2"))
					comando = new ComandoConfermaDatiCarta();
			}
			/* VISUALIZZA_INVENTARIO  */
			if (console == ElencoComandi.VISUALIZZA_INVENTARIO){
				if (parola.equals("1"))
					comando = new ComandoVisualizzaInventario();
				if (parola.equals("2"))
					comando = new ComandoSelezionaFarmaco();
			}
			
			/* RITIRO_ORDINE  */
			if (console == ElencoComandi.RITIRO_ORDINE){
				if (parola.equals("1"))
					comando = new ComandoInserisciDatiCliente();
				if (parola.equals("2"))
					comando = new ComandoConvalidaPrescrizione();
				if (parola.equals("3")) {
					comando = new ComandoConvalidaOrdine();
					check = true;
				}
				if (parola.equals("4") && !check) {
					System.out.println("Prima di effettuare la vendita bisogna effettuare la convalida ordine\n");
					comando = new ComandoRitiroOrdine();
				}
			}
			
			/* VENDITA */

			if (parola.equals("4") && check) {
				comando = new ComandoVendita();
				
			}
			
			if (console == ElencoComandi.VENDITA){
				if (parola.equals("1"))
					comando = new ComandoInserisciCodOrdine();
				if (parola.equals("2"))
					comando = new ComandoSelezionaPagamento();
				if (parola.equals("3")) {
					comando = new ComandoConfermaPagamento();
					check = false;
				}
			}
			
			
			/* VISUALIZZA_STORICO_ORDINI */
			if (console == ElencoComandi.VISUALIZZA_STORICO_ORDINI) {
				if (parola.equals("1"))
					comando = new ComandoStoricoOrdine();
				if (parola.equals("2"))
					comando = new ComandoSelezionaOrdine();
				if (parola.equals("3"))
					comando = new ComandoRifaiOrdine();
			}
			
			/* REGISTRO VENDITE */
			if (console == ElencoComandi.REGISTRO_VENDITE) {
				if (parola.equals("1"))
					comando = new ComandoInserisciIntervallo();
			}
			
			/* GESTIONE ORDINE DOMICILIO */
			if (console == ElencoComandi.GESTIONE_ORDINE_DOMICILIO) {
				if (parola.equals("1"))
					comando = new ComandoInserisciCodFiscale();
				if (parola.equals("2"))
					comando = new ComandoCheckOrdinePagato();
				if (parola.equals("3"))
					comando = new ComandoConfermaOrdineDomicilio();
			}
			
			/* REGISTAZIONE ORDINE CONSULENZA */
			if (console == ElencoComandi.REGISTRAZIONE_ORDINE_CONSULENZA) {
				if (parola.equals("1"))
					comando = new ComandoIdentificaCliente();
				if (parola.equals("2"))
					comando = new ComandoScegliFarmaco();
				if (parola.equals("3"))
					comando = new ComandoConfermaConsulenza();
			}
			
			/* TORNA AL MENU' PRECEDENTE O ESCI */
			if (parola.equals("0"))
				comando = new ComandoEsci();
	   } else comando = new ComandoNonValido();
		
       return comando;
    }
}
