package interfaccia;

import dominio.FarmApp;

public class RitiroOrdineConsole {
	public void start(FarmApp fapp) throws Exception {
		stampaBenvenuto();
		Comando comando = Parser.getInstance().getComando(ElencoComandi.RITIRO_ORDINE);
		while (!comando.getCodiceComando().equals("0")) {
				comando.esegui(fapp);
				System.out.println();
				stampaBenvenuto();
				comando = Parser.getInstance().getComando(ElencoComandi.RITIRO_ORDINE);
		}
		
		comando.esegui(fapp); 
	}

    private void stampaBenvenuto() {
        System.out.println("RITIRO ORDINE");
		System.out.println(ElencoComandi.elencoTuttiComandi(ElencoComandi.RITIRO_ORDINE));
		System.out.println("FAI LA TUA SCELTA");
	}
}
