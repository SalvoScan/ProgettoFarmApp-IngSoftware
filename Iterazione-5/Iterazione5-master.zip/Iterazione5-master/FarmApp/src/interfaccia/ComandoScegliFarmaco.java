package interfaccia;

import dominio.*;
import java.util.*;

public class ComandoScegliFarmaco implements Comando {
	public static final String codiceComando = "2";
	public static final String descrizioneComando = "Scegliere il farmaco";
	ComandoAggiungiFarmaco caf = new ComandoAggiungiFarmaco();

	public String getCodiceComando() {
		return codiceComando;
	}

	public String getDescrizioneComando() {
		return descrizioneComando;
	}

	public void esegui(FarmApp fapp) throws Exception {
		Inventario i =  fapp.getInventario();
		fapp.setInventarioCorrente(i.getListaFarmaci());
		this.caf.esegui(fapp);
		List<Farmaco> lista_farmaci = fapp.getFarmaciOrdineCorrente();
		float prezzo = fapp.getPrezzoOrdineCorrente();
		Cliente cc = fapp.getClienteConsulenza();
		
		for(Cliente c : fapp.getListaClienti()) {
			if(c.getId() == cc.getId()) {
				for(Farmaco f : lista_farmaci) {
					// Aggiornamento dell'ordine consulenza prenotato dal cliente
					Farmaco f1 = new Farmaco(f.getNumSerie(), f.getQuantita(), f.getDescrizioneFarmaco());
					c.getOrdinePrenotato().getOrdine().setFarmacoOrdinato(f1);
				}
				c.getOrdinePrenotato().setPrezzoOrdine(prezzo + cc.getOrdinePrenotato().getPrezzoOrdine());
				System.out.println("Ordine consulenza aggiornato");
			}
		}
		
	}

}
