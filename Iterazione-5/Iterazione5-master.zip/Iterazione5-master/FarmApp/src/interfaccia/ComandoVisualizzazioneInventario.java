package interfaccia;

import dominio.FarmApp;

public class ComandoVisualizzazioneInventario implements Comando{
	public static final String codiceComando="4";
	public static final String descrizioneComando="Visualizzazione inventario";
	
   	public String getCodiceComando() {
		return codiceComando;
	}
	
   	public String getDescrizioneComando() {
		return descrizioneComando;
	}

    public void esegui(FarmApp fapp) throws Exception {
    	VisualizzazioneInventarioConsole vic = new VisualizzazioneInventarioConsole();
		vic.start(fapp);
	}
}
