package interfaccia;

import dominio.*;
import java.util.*;

public class ComandoConfermaFarmaco implements Comando{
	public static final String codiceComando = "2";
	public static final String descrizioneComando = "Conferma nuovo farmaco";
	
	public String getCodiceComando() {
		return codiceComando;
	}
	
	public String getDescrizioneComando() {
		return descrizioneComando;
	}
	
	public void esegui(FarmApp fapp) {
		Farmaco farmaco_corrente = fapp.getFarmacoCorrente();
		Farmaco nuovo_farmaco = new Farmaco(farmaco_corrente.getNumSerie(), farmaco_corrente.getQuantita() ,farmaco_corrente.getDescrizioneFarmaco());
		Inventario i = fapp.getInventario();
		List<Farmaco> lf = i.getListaFarmaci();
		
		for(Farmaco f : lf) {
			if(nuovo_farmaco.getNumSerie().equals(f.getNumSerie())) {
				f.setQuantita(nuovo_farmaco.getQuantita());
				System.out.println("Operazione Terminata");
				return;
			}
		}
		
		fapp.setInventario(nuovo_farmaco);
		System.out.println("Operazione Terminata");
		
	}
	
	
}
