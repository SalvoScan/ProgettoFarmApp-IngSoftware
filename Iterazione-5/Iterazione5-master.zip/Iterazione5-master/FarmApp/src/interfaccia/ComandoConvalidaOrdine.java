package interfaccia;

import dominio.*;
import java.util.*;

public class ComandoConvalidaOrdine implements Comando {
	public static final String codiceComando = "3";
	public static final String descrizioneComando = "Convalida ordine";
	
	public String getCodiceComando() {
		return codiceComando;
	}
	
	public String getDescrizioneComando() {
		return descrizioneComando;
	}
	
	public void esegui(FarmApp fapp) {
		OrdinePrenotato ordine_corrente = fapp.getOrdinePrenotatoCorrente();
		OrdineConsegnato ordine_consegnato = new OrdineConsegnato(ordine_corrente);
		
		//Cerchiamo il cliente nella lista dei clienti e cancelliamo l'ordine prenotato
		for(Cliente c : fapp.getListaClienti()) {
			if(c.getId() == fapp.getClienteAlBanco().getId()) {
				for(OrdinePrenotato op : fapp.getListaOrdiniPrenotati()) {
					if(op.getIdCliente() == c.getId()) {
						fapp.setCancellaOrdine(op);
						break;
					}
				}
				//aggiunge l'ordine consegnato alla lista degli ordini del cliente
				c.setOrdiniConsegnati(ordine_consegnato);
				c.setOrdinePrenotato(null);
			}
		}
		
		
		//AGGIORNAMENTO INVENTARIO
		List<Farmaco> farmaci = new ArrayList<Farmaco>();
		farmaci = fapp.getInventario().getListaFarmaci();
		for(Farmaco f : farmaci) {
			for(Farmaco far : ordine_corrente.getFarmaciOrdinati()) {
					if(f.getNumSerie().equals(far.getNumSerie())) {
						f.setQuantita(f.getQuantita() - far.getQuantita());
					}
			}			
		}
		fapp.getInventario().setListaFarmaci(farmaci);
		//COLLEGARE AL CASO D'USO VENDITA SE L'ORDINE NON � STATO PAGATO
		System.out.println("L'ordine � stato aggiunto");
	}
}
