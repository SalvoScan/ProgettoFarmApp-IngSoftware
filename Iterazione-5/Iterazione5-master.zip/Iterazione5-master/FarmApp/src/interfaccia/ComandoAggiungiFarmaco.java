package interfaccia;

import java.util.*;
import dominio.*;

public class ComandoAggiungiFarmaco implements Comando{
	public static final String codiceComando = "2";
	public static final String descrizioneComando = "Aggiungi farmaci all'ordine";
	
	public String getCodiceComando() {
		return codiceComando;
	}
	
	public String getDescrizioneComando() {
		return descrizioneComando;
	}
	
	public void esegui(FarmApp farmapp) {
		float prezzo_f = 0;
		List<Farmaco> farmaci =  farmapp.getInventarioCorrente();
		if(farmaci == null) {
			System.out.println("Visualizzare prima la lista dei farmaci");
			return;
		}
		System.out.println("Inserisci il codice del farmaco: ");
		String num_serie = Parser.getInstance().read();
		System.out.println("Inserisci la quantita del farmaco: ");
		String s_quantita = Parser.getInstance().read();
		int quantita = Integer.parseInt(s_quantita);
		int flag = 0;
		while(flag == 0) {
			for(Farmaco f : farmaci) {
				if(num_serie.equals(f.getNumSerie()) && quantita > f.getQuantita()){
					System.out.println("Quantita' non disponibile");
					System.out.println("Inserisci la quantita del farmaco: ");
					s_quantita = Parser.getInstance().read();
					quantita = Integer.parseInt(s_quantita);
					break;
				}
				else if (num_serie.equals(f.getNumSerie()) && quantita <= f.getQuantita()) {
					flag = 1;
				}
			}
		}
		for (Farmaco f: farmaci){
		if(num_serie.equals(f.getNumSerie())) {
			DescrizioneFarmaco desc_farmaco = f.getDescrizioneFarmaco();
			Farmaco farmaco_corrente = new Farmaco(num_serie, quantita, desc_farmaco);
			farmapp.setFarmaciOrdineCorrente(farmaco_corrente);
			prezzo_f = farmapp.getPrezzoOrdineCorrente() + (f.getDescrizioneFarmaco().getPrezzoFarmaco() * quantita);
			farmapp.setPrezzoOrdineCorrente(prezzo_f);
		  }
		}
		List<Farmaco> farmaci_ordinati = farmapp.getFarmaciOrdineCorrente();
		for(Farmaco f_ordinati : farmaci_ordinati)
			System.out.println(" " + f_ordinati.toString());
	}
		
}
