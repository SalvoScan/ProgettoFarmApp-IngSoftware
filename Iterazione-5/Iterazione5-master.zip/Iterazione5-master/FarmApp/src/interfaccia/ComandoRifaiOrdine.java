package interfaccia;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import dominio.*;

public class ComandoRifaiOrdine implements Comando{
	public static final String codiceComando = "3";
	public static final String descrizioneComando = "Rifai ordine";
	
	public String getCodiceComando() {
		return codiceComando;
	}
	
	public String getDescrizioneComando() {
		return descrizioneComando;
	}
	
	public void esegui(FarmApp farmapp) {
		Cliente cl_autenticato = farmapp.getClienteAutenticato();
		if(cl_autenticato.getOrdinePrenotato() != null) {
			System.out.println("Esiste gi� una prenotazione attualmente in corso!");
			return;
		}
		GregorianCalendar gc = new GregorianCalendar();
		Date data_ordine = new Date();
		Date data_ritiro = new Date();
		List<String> orari = farmapp.getListaOrari();
		long anno = gc.get(Calendar.YEAR);
		long mese = gc.get(Calendar.MONTH) + 1;
		long giorno = gc.get(Calendar.DATE);
		long ora_ordine = gc.get(Calendar.HOUR_OF_DAY);
	    long ora_ritiro = gc.get(Calendar.HOUR_OF_DAY) + 3;
		long min = gc.get(Calendar.MINUTE);
		gc.add((Calendar.DATE), 1);
        long domani = gc.get(Calendar.DATE);
        
        int metodo_consegna = 1; //ordine non a domicilio
        
        System.out.println("Ricevere l'ordine a domicilio? [Y/N]");
        String s =Parser.getInstance().read();
        if(s.equals("Y")) {
        	metodo_consegna = 0;
        }
        
		OrdineConsegnato ordine_selezionato = farmapp.getOrdineSelezionato();
		List<OrdineConsegnato> storico_ordini = cl_autenticato.getOrdiniConsegnati();
		int id_cliente = cl_autenticato.getId();
		OrdinePrenotato op = new OrdinePrenotato(ordine_selezionato);
		op.setIdCliente(id_cliente);
		int cod_ordine = storico_ordini.size() + 1;
		op.setCodOrdine(cod_ordine);
		
		
	    String s_data = String.valueOf(giorno) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + String.valueOf(ora_ordine) + ":" + String.valueOf(min);
	    String s_data1;
	    if (metodo_consegna == 1) {
		    try{
		        data_ordine = new SimpleDateFormat("dd-MM-yyyy hh:mm").parse(s_data);
		        
		        if(ora_ordine >= 7 && ora_ordine <= 18){
		        	//Gestire orario 12 (viene visualizzato 00 in ora_ordine)
	                s_data1 = String.valueOf(giorno) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + String.valueOf(ora_ritiro) + ":" + String.valueOf(min);
	            }
		        else {
	                s_data1 = String.valueOf(domani) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + orari.get(0);
	            }
		        
		        data_ritiro = new SimpleDateFormat("dd-MM-yyyy hh:mm").parse(s_data1);
		        System.out.println("La data e l'ora di ritiro e': " + data_ritiro);
		        System.out.println("Confermare tale orario? Y/N");
		        String scelta = Parser.getInstance().read();
		        
		        if(scelta.equals("N")) {
		        	System.out.println("Scegli un orario tra quelli disponibili");
		        	System.out.println(orari.toString());
		        	System.out.println("Scrivi l'orario desiderato (formato hh:mm):");
		        	String scelta_orario = Parser.getInstance().read();
		        	int check = 0;
		        	for(String orari_disp : orari) {
		        		check = check + 1;
		        		if(scelta_orario.equals(orari_disp)) {
		        			farmapp.setListaOrari(scelta_orario);
		    	        	s_data1 = String.valueOf(domani) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + scelta_orario;
		    	        	data_ritiro = new SimpleDateFormat("dd-MM-yyyy hh:mm").parse(s_data1);
		    	        	break;
		        		}
		        		if(orari.size() == check) {
		        			System.out.println("Orario errato!");
		        			return;
		        		}
		        	}	
		        }
		    } catch (ParseException e) {
		    System.out.println("Orario errato!");
		    return;
		    }
	    }
	    System.out.println("Pagare con carta? [Y/N]");
		if(Parser.getInstance().read().equals("Y")) {
			if(farmapp.getClienteAutenticato().getAccount().getCartaCredito() == null) {
				System.out.println("Prima di poter pagare con carta bisogna associarla");
				System.out.println("L'ordine non verrr� pagato");
			}
			else op.setPagato(true);
		}
		
		if(metodo_consegna == 0) {
			List<Farmaco> f_ordinati = op.getFarmaciOrdinati();
			for(Farmaco f : op.getFarmaciOrdinati()) {
				if(f.getDescrizioneFarmaco().getPrescrizione()) {
					System.out.println("I farmaci ordinati a domicilio non devono avere prescrizione!");
					System.out.println("I farmaci che verranno eliminati sono: \n");
					for(Farmaco far : op.getFarmaciOrdinati()) {
						if(far.getDescrizioneFarmaco().getPrescrizione()) {
							System.out.println("Nome:" + far.getDescrizioneFarmaco().getNome()+ "\n");
						}
					}
					System.out.println("Eliminare i farmaci che la richiedono --> 1 \nOrdine non a domicilio --> 2");
					String s2 = Parser.getInstance().read();
					if(s2.equals("1")){
						
						for(Farmaco fa : f_ordinati) {
							if(fa.getDescrizioneFarmaco().getPrescrizione()) {
								op.setPrezzoOrdine(op.getPrezzoOrdine() - fa.getDescrizioneFarmaco().getPrezzoFarmaco());
								op.getFarmaciOrdinati().remove(fa);
								
							}
						}						
					}
					else if(s2.equals("2")) {
						break;
					}
					else System.out.println("Scegliere tra 1 e 2");
				}
			}
		}
	    op.setOrarioOrdine(data_ordine);
	    op.setOrarioRitiro(data_ritiro);
	    List<Cliente> lista_clienti = farmapp.getListaClienti();
	    for(Cliente c : lista_clienti) {
	    	if(c.getId() == id_cliente) {
	    		c.setOrdinePrenotato(op);	    		
	    		farmapp.setNuovoOrdine(op);
	    		System.out.println("Ordine confermato!");
	    		return;
	    	}
	    }
	}
}
