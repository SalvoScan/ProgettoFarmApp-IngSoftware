package interfaccia;

import java.util.*;

import dominio.*;

import persistenza.PersistenceFacade;

public class ComandoConfermaPagamento implements Comando {
	public static final String codiceComando = "3";
	public static final String descrizioneComando = "Conferma il pagamento";
	
	public String getCodiceComando() {
		return codiceComando;
	}

	public String getDescrizioneComando() {
		return descrizioneComando;
	}

	public void esegui(FarmApp farmapp) {
		List<OrdineConsegnato> ordini_consegnati = new ArrayList<>();
		
		
		for(Cliente c : farmapp.getListaClienti()) {
			if (c.getId() == farmapp.getClienteAlBanco().getId())
				ordini_consegnati = c.getOrdiniConsegnati();
				OrdineConsegnato oc = ordini_consegnati.get(ordini_consegnati.size() - 1);
				OrdineConsegnato ordine_venduto = new OrdineConsegnato(oc);
				ordine_venduto.setIdCliente(oc.getIdCliente());
				ordine_venduto.setMetodo(oc.getMetodo());
				ordine_venduto.addObserver(farmapp.getRegistroVendite());
				ordine_venduto.setPagato(true);
				PersistenceFacade.getInstance().aggiornaVendite(ordine_venduto);
				
		}
		System.out.println("L'ordine � stato pagato correttamente");
		System.out.println("STAMPA DELLA RICEVUTA IN CORSO . . . ");
		
	}
}
