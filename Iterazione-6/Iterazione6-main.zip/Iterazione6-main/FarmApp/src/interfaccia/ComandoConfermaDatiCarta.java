package interfaccia;

import dominio.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class ComandoConfermaDatiCarta implements Comando{
	public static final String codiceComando = "2";
	public static final String descrizioneComando = "Conferma carta di credito";
	
	public String getCodiceComando() {
		return codiceComando;
	}
	
	public String getDescrizioneComando() {
		return descrizioneComando;
	}
	
	public void esegui(FarmApp fapp) throws ParseException {
		CartaCredito cc = fapp.getCartaCreditoCorrente();
		//Viene associata la carta di credito corrente all'account del cliente
		SimpleDateFormat formato_data2 = new SimpleDateFormat ("dd.MM.yyyy");
		Date sc = new Date();
		sc = formato_data2.parse(cc.getScadenza());
		CartaCredito nuova_carta = new CartaCredito(cc.getCodIBAN(), sc , cc.getNomeIntestatario(), cc.getCognomeIntestatario());
		for(Cliente c : fapp.getListaClienti()) {
			if(c.getId() == fapp.getClienteAutenticato().getId()) {
				c.getAccount().setCartaCredito(nuova_carta);
				fapp.getPersistence().saveCarta(nuova_carta, c);
			}
		}	
		
		
		System.out.println("Operazione Terminata");
		
	}
	
	
}