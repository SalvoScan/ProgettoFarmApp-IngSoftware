package interfaccia;

import dominio.*;

public class ComandoRegistrazioneNuovoCliente implements Comando {
	public static final String codiceComando="1";
	public static final String descrizioneComando="Registrazione cliente";
	
   	public String getCodiceComando() {
		return codiceComando;
	}
	
   	public String getDescrizioneComando() {
		return descrizioneComando;
	}

    public void esegui(FarmApp fapp) throws Exception {
		RegistrazioneClienteConsole rcc = new RegistrazioneClienteConsole();
		rcc.start(fapp);
	}
}
