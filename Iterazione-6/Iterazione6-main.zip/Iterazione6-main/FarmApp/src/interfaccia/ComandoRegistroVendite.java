package interfaccia;

import dominio.FarmApp;

public class ComandoRegistroVendite implements Comando {
	public static final String codiceComando = "2";
	public static final String descrizioneComando = "Registro vendite";
	
   	public String getCodiceComando() {
		return codiceComando;
	}
	
   	public String getDescrizioneComando() {
		return descrizioneComando;
	}

    public void esegui(FarmApp fapp) throws Exception {
    	RegistroVenditeConsole rvo = new RegistroVenditeConsole();
		rvo.start(fapp);
	}
}
