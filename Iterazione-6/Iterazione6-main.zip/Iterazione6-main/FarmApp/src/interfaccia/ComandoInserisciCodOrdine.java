package interfaccia;

import dominio.*;
import java.util.*;

public class ComandoInserisciCodOrdine implements Comando {
	public static final String codiceComando = "1";
	public static final String descrizioneComando = "Codice ordine selezionato";
	
	public String getCodiceComando() {
		return codiceComando;
	}

	public String getDescrizioneComando() {
		return descrizioneComando;
	}

	public void esegui(FarmApp farmapp) {
		List<OrdineConsegnato> ordini_consegnati = new ArrayList<>();
		for(Cliente c : farmapp.getListaClienti()) {
			if (c.getId() == farmapp.getClienteAlBanco().getId()) {
				for(OrdineConsegnato o : c.getOrdiniConsegnati()) {
					ordini_consegnati.add(o);
				}
				OrdineConsegnato oc = ordini_consegnati.get(ordini_consegnati.size() - 1);
				System.out.println("INFO ORDINE SELEZIONATO");
				System.out.println(oc);
				return;
			}
		
		}
		
	}
}
