package interfaccia;

import dominio.FarmApp;

public class ComandoVisualizzaStoricoOrdini implements Comando {
	public static final String codiceComando = "4";
	public static final String descrizioneComando = "Visualizza storico ordini";
	
   	public String getCodiceComando() {
		return codiceComando;
	}
	
   	public String getDescrizioneComando() {
		return descrizioneComando;
	}

    public void esegui(FarmApp fapp) throws Exception {
    	VisualizzaStoricoOrdiniConsole vso = new VisualizzaStoricoOrdiniConsole();
		vso.start(fapp);
	}
}
