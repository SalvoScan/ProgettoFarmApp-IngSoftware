package interfaccia;

import dominio.*;

public class ComandoInserisciNuovoOrdine implements Comando{
	public static final String codiceComando="1";
	public static final String descrizioneComando="Inserisci nuovo ordine";
	
   	public String getCodiceComando() {
		return codiceComando;
	}
	
   	public String getDescrizioneComando() {
		return descrizioneComando;
	}

    public void esegui(FarmApp fapp) throws Exception {
		NuovoOrdineConsole noc = new NuovoOrdineConsole();
		noc.start(fapp);
	}
}
