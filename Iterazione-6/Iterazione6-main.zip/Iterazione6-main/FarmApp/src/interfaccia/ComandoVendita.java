package interfaccia;

import dominio.FarmApp;

public class ComandoVendita implements Comando {
	public static final String codiceComando="4";
	public static final String descrizioneComando="Vendita";
	
   	public String getCodiceComando() {
		return codiceComando;
	}
	
   	public String getDescrizioneComando() {
		return descrizioneComando;
	}

    public void esegui(FarmApp fapp) throws Exception {
    	VenditaConsole vec = new VenditaConsole();
		vec.start(fapp);
	}
}
