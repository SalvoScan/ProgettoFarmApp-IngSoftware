package interfaccia;

import java.util.List;
import dominio.*;

public class ComandoInserisciCodFiscale implements Comando {
	public static final String codiceComando = "1";
	public static final String descrizioneComando = "Inserisci il codice fiscale";
	
	public String getCodiceComando() {
		return codiceComando;
	}

	public String getDescrizioneComando() {
		return descrizioneComando;
	}

	public void esegui(FarmApp fapp) {
		List<Cliente> lista_clienti = fapp.getListaClienti();
		System.out.println("Inserisci codice fiscale del cliente:");
		String cod_fiscale = Parser.getInstance().read();
		
		for (Cliente c : lista_clienti) {
			if (cod_fiscale.equals(c.getAccount().getCodiceFiscale())) {
				fapp.setClienteAdomicilio(c);
				System.out.println("Cliente autenticato...");
				for(OrdinePrenotato op : fapp.getFattorino().getListaOrdiniDom()) {
					if(c.getId() == op.getIdCliente()) {
						System.out.println("Info ordine prenotato");
						System.out.println(c.getOrdinePrenotato());
						return;
						
					}
					
				}
				
			}	
		}
		System.out.println("Il cliente non ha ordini a domicilio");
	}
}
