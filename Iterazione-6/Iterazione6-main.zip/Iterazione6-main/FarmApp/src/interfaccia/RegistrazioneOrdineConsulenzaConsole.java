package interfaccia;

import dominio.FarmApp;

public class RegistrazioneOrdineConsulenzaConsole {
	public void start(FarmApp fapp) throws Exception {
		stampaBenvenuto();
		Comando comando = Parser.getInstance().getComando(ElencoComandi.REGISTRAZIONE_ORDINE_CONSULENZA);
		while (!comando.getCodiceComando().equals("0")) {
				comando.esegui(fapp);
				System.out.println();
				stampaBenvenuto();
				comando = Parser.getInstance().getComando(ElencoComandi.REGISTRAZIONE_ORDINE_CONSULENZA);
		}
		
		comando.esegui(fapp); 
	}

    private void stampaBenvenuto() {
        System.out.println("REGISTRAZIONE ORDINE CONSULENZA");
		System.out.println(ElencoComandi.elencoTuttiComandi(ElencoComandi.REGISTRAZIONE_ORDINE_CONSULENZA));
		System.out.println("FAI LA TUA SCELTA");
	}
}
