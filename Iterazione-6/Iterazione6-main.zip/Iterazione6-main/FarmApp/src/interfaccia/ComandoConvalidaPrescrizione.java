package interfaccia;

import dominio.*;
import java.util.*;

public class ComandoConvalidaPrescrizione implements Comando{
	public static final String codiceComando = "2";
	public static final String descrizioneComando = "Convalida prescrizioni";
	
	public String getCodiceComando() {
		return codiceComando;
	}
	
	public String getDescrizioneComando() {
		return descrizioneComando;
	}
	
	public void esegui(FarmApp fapp) {
		OrdinePrenotato ordine_corrente = fapp.getOrdinePrenotatoCorrente();
		List <Farmaco> farmaci = ordine_corrente.getFarmaciOrdinati();
		for(Farmaco f : farmaci) {
			if(f.getDescrizioneFarmaco().getPrescrizione()) {
				System.out.println("Convalida prescrizione per il farmaco:  " + f.getDescrizioneFarmaco().getNome() + "  [Y/N]");
				if(Parser.getInstance().read().equals("N")) {
					System.out.println("Non � possibile completare l'ordine, serve la prescrizione");
					return;
				}
			}
		}
		System.out.println("Sono state consegnate tutte le prescrizioni");
	}
}
