package interfaccia;

import dominio.*;

public class FarmAppConsole {
	private int mod = 1;
	public void start() throws Exception {
		FarmApp fapp = new FarmApp();
		
		boolean flag = true;
		while(mod != 0 && flag) {
			System.out.println("Inserisci Modalit� d'Uso");
			System.out.println("1 -> Amministratore\n2 -> Farmacista\n3 -> Fattorino\n4 -> Cliente\n5 -> Registrazione Cliente\n0 -> Esci");
			mod = Integer.parseInt(Parser.getInstance().read());
			if(mod < 0 || mod > 5) {
				System.out.println("Modalit� selezionata non valida");
			}else {
				switch (mod){
				case 1: System.out.println("Modalit� Amministratore"); mod = 1; flag = false; break;
				case 2: System.out.println("Modalit� Farmacista"); mod = 2; flag = false; break;
				case 3: System.out.println("Modalit� Fattorino"); mod = 3; flag = false; break;
				case 4: System.out.println("Modalit� Cliente"); mod = 4; flag = false; break;
				case 5: System.out.println("Modalit� Registrazione"); mod = 5; flag = false; break;
			};
			
			}
		}
		if(mod == 0) {
			System.out.println("Sto terminando ...");
			System.out.println("ARRIVEDERCI");
			return;
		}
		
		if(mod == 1) {
			// AMMINISTRATORE
			int x = 1;
			int count = 3;
			while(x != 0 && count > 0) {
				System.out.println("Inserisci Email");
				String email = Parser.getInstance().read();
				System.out.println("Inserisci Password");
				String password = Parser.getInstance().read();
				if(email.equals(fapp.getAmministratore().getEmail()) && password.equals(fapp.getAmministratore().getPassword())) {
					System.out.println("Amministratore autenticato");
					x = 0;
				}else {
					System.out.println("Autenticazione fallita");
					count -= 1;
					System.out.println("Tentativi rimasti : " + count);
				}
				if(count == 0) {
					System.out.println("Sto terminando ...");
					System.out.println("ARRIVEDERCI");
					return;
				}
			}
			
			
			
		}else if(mod == 2) {
			// FARMACISTA
			int x = 1;
			int count = 3;
			while(x != 0 && count > 0) {
				System.out.println("Inserisci Email");
				String email = Parser.getInstance().read();
				System.out.println("Inserisci Password");
				String password = Parser.getInstance().read();
				for(Farmacista f : fapp.getListaFarmacisti()) {
					if(f.getEmail().equals(email) && f.getPassword().equals(password)) {
						System.out.println("Farmacista autenticato");
						x = 0;
						break;
					}
				}
				if(x == 1) {
					System.out.println("Autenticazione fallita");
					count -= 1;
					System.out.println("Tentativi rimasti : " + count);
				}
				if(count == 0) {
					System.out.println("Sto terminando ...");
					System.out.println("ARRIVEDERCI");
					return;
				}			
			}
			
			
			
		}else if(mod == 3) {
			// FATTORINO
			int x = 1;
			int count = 3;
			while(x != 0 && count > 0) {
				System.out.println("Inserisci Email");
				String email = Parser.getInstance().read();
				System.out.println("Inserisci Password");
				String password = Parser.getInstance().read();
				if(email.equals(fapp.getFattorino().getEmail()) && password.equals(fapp.getFattorino().getPassword())) {
					System.out.println("Fattorino autenticato");
					x = 0;
				}else {
					System.out.println("Autenticazione fallita");
					count -= 1;
					System.out.println("Tentativi rimasti : " + count);
				}
				if(count == 0) {
					System.out.println("Sto terminando ...");
					System.out.println("ARRIVEDERCI");
					return;
				}
			}
			
			
			
		}else if(mod == 4) {
			// CLIENTE
			int x = 1;
			int count = 3;
			while(x != 0 && count > 0) {
				System.out.println("Inserisci Email");
				String email = Parser.getInstance().read();
				System.out.println("Inserisci Password");
				String password = Parser.getInstance().read();
				for(Cliente c : fapp.getListaClienti()) {
					if(c.getEmail().equals(email) && c.getPassword().equals(password)) {
						System.out.println("Cliente autenticato");
						fapp.setClienteAutenticato(c);
						x = 0;
						break;
					}
				}
				if(x == 1) {
					System.out.println("Autenticazione fallita");
					count -= 1;
					System.out.println("Tentativi rimasti : " + count);
				}
				if(count == 0) {
					System.out.println("Sto terminando ...");
					System.out.println("ARRIVEDERCI");
					return;
				}
			}
		}
		
		ElencoComandi.setModalita(mod);
		
		stampaBenvenuto();
		
		Comando comando = Parser.getInstance().getComando(ElencoComandi.FarmApp);
		
		while (!comando.getCodiceComando().equals("0")) {
			comando.esegui(fapp);
			System.out.println();
			stampaBenvenuto();
			comando = Parser.getInstance().getComando(ElencoComandi.FarmApp);
		}
		comando.esegui(fapp); 
		System.out.println("ARRIVEDERCI");
	}

    private void stampaBenvenuto() {
        System.out.println("FARMAPP");
		System.out.println(ElencoComandi.elencoTuttiComandi(ElencoComandi.FarmApp));
		System.out.println("SCEGLI");
	}
}
