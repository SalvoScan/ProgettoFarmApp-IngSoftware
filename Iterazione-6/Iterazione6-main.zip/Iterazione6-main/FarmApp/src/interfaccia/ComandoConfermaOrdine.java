package interfaccia;

import java.text.*;
import java.util.*;
import dominio.*;

public class ComandoConfermaOrdine implements Comando{
	public static final String codiceComando = "3";
	public static final String descrizioneComando = "Conferma ordine";
	
	public String getCodiceComando() {
		return codiceComando;
	}

	public String getDescrizioneComando() {
		return descrizioneComando;
	}
	
	public void esegui(FarmApp farmapp) {
		GregorianCalendar gc = new GregorianCalendar();
		Date data_ordine = new Date();
		Date data_ritiro = new Date();
		List<String> orari = farmapp.getListaOrari();
		long anno = gc.get(Calendar.YEAR);
		long mese = gc.get(Calendar.MONTH) + 1;
		long giorno = gc.get(Calendar.DATE);
		long ora_ordine = gc.get(Calendar.HOUR_OF_DAY);
	    long ora_ritiro = gc.get(Calendar.HOUR_OF_DAY) + 3;
		long min = gc.get(Calendar.MINUTE);
		gc.add((Calendar.DATE), 1);
        long domani = gc.get(Calendar.DATE);
        int metodo_consegna = 1; //ordine non a domicilio
        
        System.out.println("Ricevere l'ordine a domicilio? [Y/N]");
        String s =Parser.getInstance().read();
        if(s.equals("Y")) {
        	metodo_consegna = 0;
        }
        
        //gestione orario di creazione dell'ordine
	    String s_data = String.valueOf(giorno) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + String.valueOf(ora_ordine) + ":" + String.valueOf(min);
	    String s_data1;
	    if (metodo_consegna == 1) {
		    try{
		        data_ordine = new SimpleDateFormat("dd-MM-yyyy hh:mm").parse(s_data);
		        
		        if(ora_ordine >= 7 && ora_ordine <= 18){
		        	
	                s_data1 = String.valueOf(giorno) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + String.valueOf(ora_ritiro) + ":" + String.valueOf(min);
	            }
		        else {
	                s_data1 = String.valueOf(domani) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + orari.get(0);
	            }
		        
		        
			        data_ritiro = new SimpleDateFormat("dd-MM-yyyy hh:mm").parse(s_data1);
			        System.out.println("La data e l'ora di ritiro e': " + data_ritiro);
			        System.out.println("Confermare tale orario? Y/N");
			        String scelta = Parser.getInstance().read();
			        
			        if(scelta.equals("N")) {
			        	System.out.println("Scegli un orario tra quelli disponibili");
			        	System.out.println(orari.toString());
			        	System.out.println("Scrivi l'orario desiderato (formato hh:mm):");
			        	String scelta_orario = Parser.getInstance().read();
			        	int check = 0;
			        	for(String orari_disp : orari) {
			        		check = check + 1;
			        		if(scelta_orario.equals(orari_disp)) {
			        			farmapp.setListaOrari(scelta_orario);
			    	        	s_data1 = String.valueOf(domani) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + scelta_orario;
			    	        	data_ritiro = new SimpleDateFormat("dd-MM-yyyy hh:mm").parse(s_data1);
			    	        	break;
			        		}
			        		if(orari.size() == check) {
			        			System.out.println("Orario errato!");
			        			return;
			        		}
			        	}	
			        }
			    } catch (ParseException e) {
			    System.out.println("Orario errato!");
			    return;
			    }
	    }
	    
	    else {
	    	try {
    	 	data_ordine = new SimpleDateFormat("dd-MM-yyyy hh:mm").parse(s_data);
	    	data_ritiro = null;
	    	} catch (ParseException e) {
			    System.out.println("Orario errato!");
			    return;
			    }
	    }
	    Cliente cl_autenticato = farmapp.getClienteAutenticato();
	    List<OrdineConsegnato> ordini = cl_autenticato.getOrdiniConsegnati();
		List<Farmaco> farmaci_ordinati = farmapp.getFarmaciOrdineCorrente();
		float prezzo_finale = farmapp.getPrezzoOrdineCorrente();
		int cod_ordine = ordini.size() + 1;
		OrdineCompleto ordine_corrente = new OrdineCompleto(cod_ordine, prezzo_finale, data_ordine, data_ritiro, farmaci_ordinati);
		OrdinePrenotato ordine_prenotato = new OrdinePrenotato(ordine_corrente);
		System.out.println("Pagare con carta? [Y/N]");
		if(Parser.getInstance().read().equals("Y")) {
			if(farmapp.getClienteAutenticato().getAccount().getCartaCredito() == null) {
				System.out.println("Prima di poter pagare con carta bisogna associarla");
				System.out.println("L'ordine non verrr� pagato");
			}
			else ordine_prenotato.setPagato(true);
		}
		
		if(metodo_consegna == 0) {
			List<Farmaco> f_ordinati = ordine_prenotato.getFarmaciOrdinati();
			for(Farmaco f : ordine_prenotato.getFarmaciOrdinati()) {
				if(f.getDescrizioneFarmaco().getPrescrizione()) {
					System.out.println("I farmaci ordinati a domicilio non devono avere prescrizione!");
					System.out.println("I farmaci che verranno eliminati sono: \n");
					for(Farmaco far : ordine_prenotato.getFarmaciOrdinati()) {
						if(far.getDescrizioneFarmaco().getPrescrizione()) {
							System.out.println("Nome:" + far.getDescrizioneFarmaco().getNome()+ "\n");
						}
					}
					System.out.println("Eliminare i farmaci che la richiedono --> 1 \nOrdine non a domicilio --> 2");
					String s2 = Parser.getInstance().read();
					if(s2.equals("1")){
						
						for(Farmaco fa : f_ordinati) {
							if(fa.getDescrizioneFarmaco().getPrescrizione()) {
								ordine_prenotato.setPrezzoOrdine(ordine_prenotato.getPrezzoOrdine() - fa.getDescrizioneFarmaco().getPrezzoFarmaco());
								ordine_prenotato.getFarmaciOrdinati().remove(fa);
								
							}
						}						
					}
					else if(s2.equals("2")) {
						break;
					}
					else System.out.println("Scegliere tra 1 e 2");
				}
			}
		}
		
		for(Cliente c : farmapp.getListaClienti()) {
			if(c.getId() == farmapp.getClienteAutenticato().getId()) {
				ordine_prenotato.setIdCliente(c.getId());
				c.setOrdinePrenotato(ordine_prenotato);
				farmapp.setNuovoOrdine(ordine_prenotato);
				farmapp.setPrezzoOrdineCorrente(0);
				System.out.println("Ordine confermato!");
				return;
			}
		}		
		
		// se l'ordine � a domicilio lo aggiungiamo alla lista degli ordini del fattorino
		if(metodo_consegna == 0) {
			OrdinePrenotato domicilio = new OrdinePrenotato(ordine_prenotato);
			domicilio.setPagato(ordine_prenotato.getPagato());
			domicilio.setIdCliente(ordine_prenotato.getIdCliente());
			farmapp.setNuovoOrdine(domicilio);
			farmapp.getFattorino().setListaOrdiniDom(domicilio);
			farmapp.setPrezzoOrdineCorrente(0);
			
			System.out.println("Ordine confermato!");
		}
		
		
	}
}
