package Test;

import static org.junit.jupiter.api.Assertions.*;

import dominio.*;
import interfaccia.*;

import java.util.*;

import org.junit.jupiter.api.Test;

class TestRifaiOrdine {
	FarmApp fapp = new FarmApp();
	ComandoRifaiOrdine cro = new ComandoRifaiOrdine();
	
	@Test
	void testRifaiOrdine() {
		OrdineConsegnato oc = new OrdineConsegnato(fapp.getClienteAutenticato().getOrdinePrenotato());
		fapp.setOrdineSelezionato(oc);
		fapp.getClienteAutenticato().setOrdinePrenotato(null);
		cro.esegui(fapp);
		
		List<Farmaco> lf = fapp.getClienteAutenticato().getOrdinePrenotato().getFarmaciOrdinati();
		assertEquals(oc.getFarmaciOrdinati().get(0).getDescrizioneFarmaco().getNome() , lf.get(0).getDescrizioneFarmaco().getNome());
	}

}
