package dominio;

import java.util.*;

public class Ordine implements OrdineInterfaccia{
	private int cod_ordine;
	private float prezzo_ordine;
	private Date orario_ordine;
	private Date orario_ritiro;
	private List<Farmaco> farmaci_ordinati = new ArrayList<>();
	//COSTRUTTORE

	public Ordine(int cod_ordine, float prezzo_ordine, Date orario_ordine, Date orario_ritiro, List<Farmaco> farmaci_ordinati) {

		this.cod_ordine = cod_ordine;
		this.prezzo_ordine = prezzo_ordine;
		this.orario_ordine = orario_ordine;
		this.orario_ritiro = orario_ritiro;
		this.farmaci_ordinati = farmaci_ordinati;
	}
	
	public Ordine() {
		
	}
	
	//METODI GETTER
	
	public int getCodOrdine() {
		return cod_ordine;
	}
	
	public Date getOrarioOrdine() {
		return orario_ordine;
	}
		
	public Date getOrarioRitiro() {
		return orario_ritiro;
	}
	
	public float getPrezzoOrdine() {
		return prezzo_ordine;
	}
	
	public List<Farmaco> getFarmaciOrdinati() {
		return farmaci_ordinati;
	}
	
	
	//METODI SETTER

	public void setPrezzoOrdine(float po) {
		this.prezzo_ordine = po;
	}
	
	public void setCodOrdine(int co) {
		this.cod_ordine = co;
	}	
	
	public void setOrarioOrdine(Date oo) {
		this.orario_ordine = oo;
	}
	public void setOrarioRitiro(Date or) {
		this.orario_ritiro = or;
	}
	
	public void setFarmaciOrdinati(List<Farmaco> farmaci_ordinati) {
		this.farmaci_ordinati = farmaci_ordinati;
	}
	
	public void setFarmacoOrdinato(Farmaco f) {
		if(this.farmaci_ordinati == null) {
			this.farmaci_ordinati = new ArrayList<>();
		}
		this.farmaci_ordinati.add(f);
	}
	
	//Metodo toString
	
	public String toString() {
		String s1 = "Ordine\n";
		String s2 = "Codice : " + cod_ordine + "\n"+ "Orario : " + orario_ordine + "\n" + "Ritiro : " + orario_ritiro + "\n" +"Prezzo" + prezzo_ordine + "\n";
		String s3 = "Lista Farmaci\n";
		String s;
		if (this.farmaci_ordinati == null) {
			s = s1 + s2;
		}
		else {
			for(Farmaco f : this.farmaci_ordinati) {
					s3 += f.toString();
			}
			s = s1 + s2 +s3;
		}
		
		return s;
	} 
}
