package dominio;

import java.util.Date;
import java.util.List;

public interface OrdineInterfaccia {
	public int getCodOrdine();
	public Date getOrarioOrdine();
	public float getPrezzoOrdine();
	public Date getOrarioRitiro();
	public List<Farmaco> getFarmaciOrdinati();
	
	public void setPrezzoOrdine(float po);
	public void setCodOrdine(int co);
	public void setOrarioOrdine(Date oo);
	public void setOrarioRitiro(Date or);
	public void setFarmaciOrdinati(List<Farmaco> farmaci_ordinati);
}
