package dominio;

import java.util.*;

public class Cliente {
	private int id;
	private String email;
	private String password;
	private Account a;
	private OrdinePrenotato op = null;
	private List<OrdineConsegnato> ordini_consegnati = new ArrayList<OrdineConsegnato>();
	
	//COSTRUTTORE
	public Cliente(String email, String password, Account a) {
		this.email = email;
		this.password = password;
		this.a = a;
	}

	//METODI GETTER

	public int getId() {
		return id;
	}

	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}
	
	public Account getAccount() {
		return a;
	}
	
	public OrdinePrenotato getOrdinePrenotato() {
		return this.op;
	}
	
	public List<OrdineConsegnato> getOrdiniConsegnati() {
		return this.ordini_consegnati;
	}
	
	//METODI SETTER

	public void setEmail(String email) {
		this.email = email;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setAccount(Account a) {
		this.a = a;
	}
	
	public void setOrdinePrenotato(OrdinePrenotato ordine_prenotato) {
		this.op = ordine_prenotato;
	}
	
	public void setOrdiniConsegnati(OrdineConsegnato oc) {
		this.ordini_consegnati.add(oc);
	}

	@Override
	public String toString() {
		return "Cliente id=" + id + "\n" + "email=" + email + "\n" + "password=" + password;
	}
	
	
	
	
}
