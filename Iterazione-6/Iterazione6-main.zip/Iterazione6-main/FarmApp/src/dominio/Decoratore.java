package dominio;

import java.util.*;
import java.util.List;

abstract class Decoratore implements OrdineInterfaccia{
	private Ordine ordine;
	private List<Farmaco> farmaci_ordinati = new ArrayList<>();
	
	
	public Decoratore(Ordine o) {
		if(o.getFarmaciOrdinati() == null) {
			this.farmaci_ordinati = new ArrayList<>();
			OrdineConsulenza oc = new OrdineConsulenza(o.getCodOrdine(), 15, o.getOrarioOrdine(), o.getOrarioRitiro(), this.farmaci_ordinati);
			this.ordine = oc;
		}else {
			this.farmaci_ordinati = new ArrayList<>();
			for(Farmaco f : o.getFarmaciOrdinati()) {
				Farmaco nf = new Farmaco(f.getNumSerie(), f.getQuantita(), f.getDescrizioneFarmaco());
				this.farmaci_ordinati.add(nf);
			}
			OrdineCompleto oc = new OrdineCompleto(o.getCodOrdine(), o.getPrezzoOrdine(), o.getOrarioOrdine(), o.getOrarioRitiro(), this.farmaci_ordinati);
			this.ordine = oc;
		}
		
		
	}
	
	//METODI GETTER
	
	public int getCodOrdine() {
		return ordine.getCodOrdine();
	}
	
	public Date getOrarioOrdine() {
		return ordine.getOrarioOrdine();
	}
		
	public Date getOrarioRitiro() {
		return ordine.getOrarioRitiro();
	}
	
	public float getPrezzoOrdine() {
		return ordine.getPrezzoOrdine();
	}
	
	public List<Farmaco> getFarmaciOrdinati() {
		return ordine.getFarmaciOrdinati();
	}
	
	public Ordine getOrdine() {
		return ordine;
	}
	
	
	//METODI SETTER

	public void setPrezzoOrdine(float po) {
		ordine.setPrezzoOrdine(po); 
	}
	
	public void setCodOrdine(int co) {
		ordine.setCodOrdine(co);
	}	
	
	public void setOrarioOrdine(Date oo) {
		ordine.setOrarioOrdine(oo);
	}
	public void setOrarioRitiro(Date or) {
		ordine.setOrarioRitiro(or); 
	}
	
	public void setFarmaciOrdinati(List<Farmaco> farmaci_ordinati) {
		ordine.setFarmaciOrdinati(farmaci_ordinati); 
	}
	
public void setFarmacoOrdinato(Farmaco f) {
		ordine.setFarmacoOrdinato(f);	
	}
	
	//Metodo toString
	
	public String toString() {
		return ordine.toString();
	} 
}
