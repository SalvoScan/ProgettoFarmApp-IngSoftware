package dominio;

import java.util.*;

public class Fattorino {
	private int id;
	private String email;
	private String password;
	private List<OrdinePrenotato> ordini_domicilio;
	
	public Fattorino(int id, String email, String password) {
		this.id = id;
		this.email = email;
		this.password = password;
		this.ordini_domicilio = new ArrayList<>();
	}
	
	//METODI GETTER

	public int getId() {
		return id;
	}

	public String getPassword() {
		return password;
	}
	

	public String getEmail() {
		return email;
	}
	
	public List<OrdinePrenotato> getListaOrdiniDom(){
		return this.ordini_domicilio;
	}

	
	//METODI SETTER

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPassword(String password) {
		this.password = password;
	};
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setListaOrdiniDom(OrdinePrenotato ordine){
		this.ordini_domicilio.add(ordine);
	}
}
