package dominio;


import java.util.*;

import persistenza.PersistenceFacade;

public class FarmApp {
	private Inventario inventario;
	private List<String> orari = new ArrayList<String>();
	private List<Cliente> lista_clienti;
	private List<Farmacista> lista_farmacisti;
	private List<OrdinePrenotato> ordini_prenotati;
	private RegistroVendite registro_vendite;
	private Fattorino fattorino;
	private Farmacista farmacista;
	private Amministratore amministratore;
	private PersistenceFacade pf;
	
	//Attributi per i Comandi
	
	private Farmaco farmaco_corrente;
	private CartaCredito carta_credito_corrente;
	private Cliente cliente_autenticato;
	private Cliente cliente_corrente;
	private List<Farmaco> inventario_corrente;
	private List<Farmaco> farmaci_ordine_corrente = new ArrayList<Farmaco>();
	private float prezzo_ordine_corrente = 0;
	private OrdinePrenotato ordine_prenotato_corrente;
	private OrdinePrenotato ordine_prenotato_domicilio;
	private Cliente cliente_albanco;
	private Cliente cliente_adomicilio;
	private int metodo_domicilio = 0;
	private OrdineConsegnato ordine_selezionato_corrente;
	private Cliente cliente_consulenza;
	
	
	
	//Costruttore
	public FarmApp() {
		this.inventario = new Inventario();
		this.lista_clienti = new ArrayList<Cliente>();
		this.lista_farmacisti = new ArrayList<Farmacista>();
		this.ordini_prenotati = new ArrayList<OrdinePrenotato>();
		this.registro_vendite = new RegistroVendite();
		this.pf = PersistenceFacade.getInstance();
		caricaDatiProva();
	}
	
	/* Carica dei dati iniziali di prova. */ 
	private void caricaDatiProva() {
		this.lista_clienti = pf.trovaClienti();
		caricaDescrizioniFarmaci();
		caricaFarmaci();
		caricaOrdini();
		caricaListaOrari();
		this.fattorino = pf.trovaFattorino();
		this.amministratore = pf.trovaAmministratore();
		this.lista_farmacisti = pf.trovaFarmacisti();
	}

	/* inizializza il catalogo delle descrizioni dei farmaci 
	   La lista delle descrizioni dei farmaci � fornita da un servizio esterno */
	private void caricaDescrizioniFarmaci() {
		List<DescrizioneFarmaco> descrizioni = pf.trovaDescrizioni();
		for(DescrizioneFarmaco df : descrizioni) {
			this.inventario.setNuovaDescrizioneFarmaco(df);
		}
	}
	
	public void caricaFarmaci() {
		List<Farmaco> farmaci = pf.loadFarmaci();
		for(Farmaco f: farmaci) {
			this.inventario.setNuovoFarmaco(f);
		}
	}

	
	/* Inizializza la lista gli orari */
	private void caricaListaOrari() {
		for (int i = 10; i <= 20; i++) {
			this.orari.add(String.valueOf(i) + ":00");
			this.orari.add(String.valueOf(i) + ":15");
			this.orari.add(String.valueOf(i) + ":30");
			this.orari.add(String.valueOf(i) + ":45");
		}
	}
		
	public void caricaOrdini(){
		List<OrdinePrenotato> ordini = pf.loadOrdiniPrenotati();
		for(OrdinePrenotato op : ordini) {
			this.ordini_prenotati.add(op);
			for (Cliente c : lista_clienti) {
				if(op.getIdCliente() == c.getId()) {
					c.setOrdinePrenotato(op);
				}
			}
			
			if(op.getOrarioRitiro() == null) {
				fattorino.setListaOrdiniDom(op);
			}
	}
		for(Cliente c : this.lista_clienti) {	
			List<OrdineConsegnato> ordini_c = pf.loadOrdiniConsegnato(c);
			for(OrdineConsegnato oc : ordini_c) {
				if(c.getId() == oc.getIdCliente()) {
					c.setOrdiniConsegnati(oc);
				}
				if(oc.getPagato()) {
					registro_vendite.setOrdineConsegnato(oc);
				}
			}
		}		
	}
	//Metodi GETTER
	
	public Inventario getInventario() {
		return this.inventario;
	}
	
	public List<Cliente> getListaClienti(){
		return this.lista_clienti;
	}
	
	public List<Farmacista> getListaFarmacisti(){
		return this.lista_farmacisti;
	}
	
	public List<OrdinePrenotato> getListaOrdiniPrenotati(){
		return this.ordini_prenotati;
	}

	public List<Farmaco> getInventarioCorrente(){
		return this.inventario_corrente;
	}
	
	public List<Farmaco> getFarmaciOrdineCorrente(){
		return this.farmaci_ordine_corrente;
	}
	
	public float getPrezzoOrdineCorrente() {
		return this.prezzo_ordine_corrente;
	}
	
	public Farmaco getFarmacoCorrente() {
		return this.farmaco_corrente;
	}
	
	public CartaCredito getCartaCreditoCorrente() {
		return this.carta_credito_corrente;
	}
	
	public Cliente getClienteAutenticato() {
		return this.cliente_autenticato;
	}
	
	public Cliente getClienteCorrente() {
		return this.cliente_corrente;
	}
	
	public Cliente getClienteAlBanco() {
		return this.cliente_albanco;
	}
	
	public List<String> getListaOrari(){
		return orari;
	}
	
	public OrdinePrenotato getOrdinePrenotatoCorrente() {
		return this.ordine_prenotato_corrente;
	}
	
	public OrdineConsegnato getOrdineSelezionato() {
		return this.ordine_selezionato_corrente;
	}
	
	public RegistroVendite getRegistroVendite() {
		return this.registro_vendite;
	}
	
	public Cliente getClienteAdomicilio() {
		return this.cliente_adomicilio;
	}
	
	public OrdinePrenotato getOrdinePrenotatoDomicilio() {
		return this.ordine_prenotato_domicilio;
	}
	
	public int getMetodo() {
		return this.metodo_domicilio;
	}
	
	public Fattorino getFattorino() {
		return this.fattorino;
	}
	
	public Cliente getClienteConsulenza() {
		return this.cliente_consulenza;
	}
	
	public Farmacista getFarmacista() {
		return this.farmacista;
	}
	
	public Amministratore getAmministratore() {
		return this.amministratore;
	}
	
	public PersistenceFacade getPersistence() {
		return this.pf;
	}
	
	
	//Metodi SETTER
	
	public void setNuovoCliente(Cliente cliente) {
		PersistenceFacade.getInstance().salvaCliente(cliente);
		this.lista_clienti = pf.trovaClienti();
	}
	
	public void setNuovoOrdine(OrdinePrenotato ordine) {
		PersistenceFacade.getInstance().saveOrdine(ordine);
		caricaOrdini();
	}
	
	public void setNuovoOrdineConsulenza(OrdinePrenotato ordine) {
		PersistenceFacade.getInstance().saveOrdineConsulenza(ordine);
		caricaOrdini();
	}
	
	public void setCancellaOrdine(OrdinePrenotato ordine) {
		this.ordini_prenotati.remove(ordine);
	}

	public void setClienteCorrente(Cliente nuovo_cliente) {
		this.cliente_corrente = nuovo_cliente;		
	}
	
	public void setClienteAlBanco(Cliente c) {
		this.cliente_albanco = c;		
	}
	
	public void setFarmacoCorrente(Farmaco farmaco_corrente) {
		this.farmaco_corrente = farmaco_corrente;
	}
	
	public void setCartaCreditoCorrente(CartaCredito carta_credito_corrente) {
		this.carta_credito_corrente = carta_credito_corrente;
	}
	
	public void setInventario(Farmaco farmaco) {
		PersistenceFacade.getInstance().saveFarmaco(farmaco);
		caricaFarmaci();
		
	}
	
	public void setClienteAutenticato(Cliente cliente_autenticato) {
		this.cliente_autenticato = cliente_autenticato;
	}
	
	public void setInventarioCorrente(List<Farmaco> inv){
		this.inventario_corrente = inv;
	}
	
	public void setFarmaciOrdineCorrente(Farmaco farmaco) {
		this.farmaci_ordine_corrente.add(farmaco);
	}
	
	public void setPrezzoOrdineCorrente(float prezzo_ordine_corrente) {
		this.prezzo_ordine_corrente = prezzo_ordine_corrente;
	}
	
	public void setListaOrari(String orario) {
		this.orari.remove(orario);
	}
	
	public void setOrdinePrenotatoCorrente(OrdinePrenotato prenotato) {
		this.ordine_prenotato_corrente = prenotato;
	}
	
	public void setOrdineSelezionato(OrdineConsegnato ordine_selezionato_corrente) {
		this.ordine_selezionato_corrente = ordine_selezionato_corrente;
	}
	
	public void setRegistroVendite(OrdineConsegnato oc) {
		this.registro_vendite.setOrdineConsegnato(oc);
	}
	
	public void setClienteAdomicilio (Cliente ca) {
		this.cliente_adomicilio = ca;
	}
	
	public void setOrdinePrenotatoDomicilio(OrdinePrenotato oc) {
		this.ordine_prenotato_domicilio = oc;
	}
	
	public void setMetodo(int metodo) {
		this.metodo_domicilio = metodo;
	}
	
	public void setClienteConsulenza(Cliente cliente_consulenza) {
		this.cliente_consulenza = cliente_consulenza;
	}
	
	public void setPersistence(PersistenceFacade pf) {
		this.pf = pf;
	}
	
}
