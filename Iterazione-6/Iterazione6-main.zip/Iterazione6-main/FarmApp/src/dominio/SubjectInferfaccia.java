package dominio;

public interface SubjectInferfaccia {
	public void addObserver(RegistroVendite rv);
	public void removeObserver();
	public void notifyObserver();
}
