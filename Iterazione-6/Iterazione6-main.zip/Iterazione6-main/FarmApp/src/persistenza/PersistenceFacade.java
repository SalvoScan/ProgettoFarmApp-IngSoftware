package persistenza;
import dominio.*;
import java.util.*;

public class PersistenceFacade {
	private static PersistenceFacade singleton;
	
	public static synchronized PersistenceFacade getInstance(){
		if (singleton == null)
			singleton = new PersistenceFacade();
		return singleton;
	}
	
	/**
	 * Restituisce i clienti registrati nel sistema
	 * @return i clienti
	 */
	public List<Cliente> trovaClienti() {
		List<Cliente> clienti = new ArrayList<>();
		/* carica le informazioni registrate nella base di dati sui clienti */
		clienti = DAOCliente.getInstance().selectClienti();		
		return clienti;
	}
	
	/**
	 * Restituisce i farmacisti registrati nel sistema
	 * @return i farmacisti
	 */
	public List<Farmacista> trovaFarmacisti(){
		List<Farmacista> farmacisti = new ArrayList<>();
		farmacisti= DAOFarmacista.getInstance().selectFarmacista();
		return farmacisti;
	}
	
	/**
	 * Restituisce l'amministratore registrati nel sistema
	 * @return amministratore
	 */
	public Amministratore trovaAmministratore(){
		Amministratore amministratore = DAOAmministratore.getInstance().selectAmministratore();
		return amministratore;
	}
	
	/**
	 * Restituisce il fattorino registrati nel sistema
	 * @return il fattorino
	 */
	public Fattorino trovaFattorino(){
		Fattorino fattorino = DAOFattorino.getInstance().selectFattorino();
		return fattorino;
	}
	
	/**
	 * aggiunge il cliente registrato al database
	 * @return
	 */
	
	public void salvaCliente(Cliente c) {
		DAOCliente.getInstance().saveCliente(c);
		return;
	}
	
	/**
	 * Restituisce le descrizioni dei farmaci registrati nel sistema
	 * @return le descrizioni
	 */
	public List<DescrizioneFarmaco> trovaDescrizioni() {
		List<DescrizioneFarmaco> inv = new ArrayList<>();
		
		inv = DAODescrizioneFarmaco.getInstance().selectFarmaci();		
		return inv;
	}
	
	/**
	 * aggiunge la carta di credito al database
	 * @return
	 */
	
	public void saveCarta(CartaCredito cc, Cliente c) {
		DAOCartaCredito.getInstance().saveCartaCredito(cc, c);
		return;
	}
	
	/**
	 * aggiunge i farmaci al database
	 * @return
	 */
	
	public void saveFarmaco(Farmaco f) {
		List<Farmaco> inv = new ArrayList<>();
		DAOFarmaco.getInstance().saveFarmaco(f);
		return;
	}
	
	/**
	 * carica i farmaci dal database all'inventario
	 * @return
	 */
	
	public List<Farmaco> loadFarmaci() {
		List<Farmaco> farmaci = new ArrayList<>();
		farmaci = DAOFarmaco.getInstance().caricaFar();
		return farmaci;
	}
	

	/**
	 * aggiunge la prenotazione di un ordine al database
	 * @return
	 */
	
	public void saveOrdine(OrdinePrenotato o) {
		DAOOrdine.getInstance().saveOrdine(o);
		return;
	}
	
	/**
	 * carica gli ordini prenotati dal database
	 * @return
	 */
	public List<OrdinePrenotato> loadOrdiniPrenotati() {
		List<OrdinePrenotato> ordini = new ArrayList<>();
		ordini = DAOOrdine.getInstance().caricaPrenotati();
		return ordini;
	}
	
	/**
	 * carica gli ordini consegnati dal database
	 * @return
	 */
	public List<OrdineConsegnato> loadOrdiniConsegnato(Cliente c) {
		List<OrdineConsegnato> ordini = new ArrayList<>();
		ordini = DAOOrdine.getInstance().caricaConsegnati(c);
		return ordini;
	}
	
	public void saveOrdineConsegnato(OrdineConsegnato o) {
		DAOOrdine.getInstance().saveConsegnato(o);
		return;
	}

	public void saveOrdineConsulenza(OrdinePrenotato op) {
		OrdineConsulenza oc = new OrdineConsulenza(op.getCodOrdine(), op.getPrezzoOrdine(), op.getOrarioOrdine(), op.getOrarioRitiro(), op.getFarmaciOrdinati());
		oc.setFarmaciOrdinati(op.getFarmaciOrdinati());
		OrdinePrenotato ordine = new OrdinePrenotato(oc);
		ordine.setIdCliente(op.getIdCliente());
		ordine.setPagato(op.getPagato());
		DAOOrdine.getInstance().saveOrdineConsulenza(ordine);
		return;
		
	}

	public void aggiornaVendite(OrdineConsegnato oc) {
		DAOOrdine.getInstance().setVenduto(oc);
		return;
	}
}
