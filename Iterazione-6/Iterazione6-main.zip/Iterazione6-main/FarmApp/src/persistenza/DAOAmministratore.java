package persistenza;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dominio.*;

public class DAOAmministratore {
private static DAOAmministratore singleton;
	
	public static synchronized DAOAmministratore getInstance(){
		if (singleton == null)
			singleton = new DAOAmministratore();
		return singleton;
	}
	//funzione per caricare i farmacisti registrati dal database all'applicazione
	public Amministratore selectAmministratore(){
		Amministratore amministratore = null;
		try {
			Connection cn;
			Statement st;
			ResultSet rs;
			String sql;
			
			// Connessione
			try {			
				Class.forName("com.mysql.jdbc.Driver");
			}catch(ClassNotFoundException e) {
				System.out.println("ClassNotFoundException: ");
				System.out.println(e.getMessage());
			}
					
			// Si crea la connessione al Database
			cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fapp?user=root&password=");
					
			// QUERY SUL DB	
			sql = "SELECT * FROM Amministratore;";
				// Si crea sempre uno Statement sulla connessione
				st = cn.createStatement(); 
						
				// Si effettua la query su uno Statement
				rs = st.executeQuery(sql);
				
				
				while (rs.next() == true) {
					int id = rs.getInt("Id");		
					String email = rs.getString("Email");
					String password = rs.getString("Password");
					amministratore = new Amministratore(id, email, password);
				}
					
			// Chiusura connessione
			cn.close();
		}catch(SQLException e) {
			System.out.println("Errore nel caricamento dei dati dal database");
		}	
		return amministratore;
	}
}
