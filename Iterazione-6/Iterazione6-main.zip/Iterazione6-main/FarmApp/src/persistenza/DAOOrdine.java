package persistenza;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import dominio.*;

public class DAOOrdine {
	private static DAOOrdine singleton;
	
	public static synchronized DAOOrdine getInstance(){
		if (singleton == null)
			singleton = new DAOOrdine();
		return singleton;
	}

	public void saveOrdine(OrdinePrenotato o) {
		try {
			Connection cn;
			PreparedStatement st;
				
				
				// Connessione
		try {					
			Class.forName("com.mysql.jdbc.Driver");
		}catch(ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: ");
			System.out.println(e.getMessage());
		}
				
		// Si crea la connessione al Database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fapp?user=root&password=");
		//controlliamo se � ordine completo o consulenza
		Ordine or = o.getOrdine();
		if(or.getClass() == OrdineCompleto.class || (or.getClass() == OrdineConsulenza.class && o.getFarmaciOrdinati() == null)) {
			st = cn.prepareStatement("INSERT INTO ORDINE_PRENOTATO values(?,?,?,?,?,?)");
			st.setInt(1, o.getCodOrdine());
			st.setInt(2, o.getIdCliente());
			st.setFloat(3, o.getPrezzoOrdine());

			SimpleDateFormat formato_data = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss");
			String o1 = formato_data.format(o.getOrarioOrdine());
			//se l'ordine � a domicilio non ho un orario di ritiro
			st.setTimestamp(4, java.sql.Timestamp.valueOf(o1));
			if(o.getOrarioRitiro() == null) {
				st.setNull(5, 0);
			}
			else {
				String o2 = formato_data.format(o.getOrarioRitiro());
				st.setTimestamp(5, java.sql.Timestamp.valueOf(o2));
			}
			
			st.setBoolean(6, o.getPagato());
			st.executeUpdate();
		}
		
		//SALVATAGGIO DEI FARMACI RELATIVI ALL'ORDINE
		if(o.getFarmaciOrdinati() != null) {
			for(Farmaco f : o.getFarmaciOrdinati()) {
				PreparedStatement st2 = cn.prepareStatement("INSERT INTO FARMACI_ORDINATI values(?,?,?)");
				st2.setInt(1, o.getIdCliente());
				st2.setString(2, f.getNumSerie());
				st2.setInt(3, f.getQuantita());
				st2.executeUpdate();
				}
			}
			
			// Chiusura connessione
			cn.close();
		
		} catch (SQLException e) {
			System.out.println("errore:" + e.getMessage());
		}
}
	

		
		
		
		public List<OrdinePrenotato> caricaPrenotati() {
			List<OrdinePrenotato> ordini = new ArrayList<>();
			List<Farmaco> farmaci = new ArrayList<>();
			try {
				Connection cn;
				Statement st;
				ResultSet rs;
				String sql;
				
				// Connessione
		try {					
			Class.forName("com.mysql.jdbc.Driver");
		}catch(ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: ");
			System.out.println(e.getMessage());
		}
				
		// Si crea la connessione al Database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fapp?user=root&password=");
				
		// QUERY SUL DB	
		sql = "SELECT * FROM ORDINE_PRENOTATO";
			try {
				// Si crea sempre uno Statement sulla connessione
				st = cn.createStatement(); 
						
				// Si effettua la query su uno Statement
				rs = st.executeQuery(sql);
						
				while (rs.next() == true) {
					int cod_ordine = rs.getInt("Codice_ordine");
					int id_cliente = rs.getInt("Codice_ut");
					float prezzo = rs.getFloat("Prezzo");
					Boolean pagato = rs.getBoolean("Pagato");
					//conversione date dell'ordine
					String y = rs.getString("Orario_ordine").substring(0,4);
					String m = rs.getString("Orario_ordine").substring(5,7);
					String g = rs.getString("Orario_ordine").substring(8,10);
					String ora = rs.getString("Orario_ordine").substring(11,13);
					String min = rs.getString("Orario_ordine").substring(14,16);
					String orario_ordine = g + "." + m + "." + y + " " + ora + ":"+ min;
					SimpleDateFormat formato_data2 = new SimpleDateFormat ("dd.MM.yyyy HH:mm");
					
					Date or = new Date();
					or = formato_data2.parse(orario_ordine);
					Date or_rit = new Date();
					//conversione date ritiro
					if(rs.getString("Orario_ritiro") != null) {
						y = rs.getString("Orario_ritiro").substring(0,4);
						m = rs.getString("Orario_ritiro").substring(5,7);
						g = rs.getString("Orario_ritiro").substring(8,10);
						ora = rs.getString("Orario_ritiro").substring(11,13);
						min = rs.getString("Orario_ritiro").substring(14,16);
						String orario_ritiro = g + "." + m + "." + y + " " + ora + ":"+ min;
						
						
						or_rit = formato_data2.parse(orario_ritiro);
					}
					else {
						
						or_rit = null;
					}
					
					//caricamento farmaci relativi all'ordine
					PreparedStatement st2 = cn.prepareStatement("SELECT * FROM FARMACI_ORDINATI f WHERE f.ID_CLIENTE = ?");
					st2.setInt(1, id_cliente);
					ResultSet rs2 = st2.executeQuery();
					
					while(rs2.next() == true) {
					
						String num_serie = rs2.getString("Num_serie_farm");
						int quantita = rs2.getInt("Quantita");
						//recupero descrizioni farmaco
						PreparedStatement st3 = cn.prepareStatement("SELECT * FROM DESC_FARMACO df WHERE df.NUM_SERIE = ?");
						st3.setString(1, num_serie);
						ResultSet rs3 = st3.executeQuery();
						while(rs3.next() == true) {
							String nome = rs3.getString("Nome");
							Boolean prescrizione = rs3.getBoolean("Prescrizione");
							String sintomi = rs3.getString("Sintomi");
							String eff_co = rs3.getString("Effetti_collaterali");
							Float prezzo_f = rs3.getFloat("Prezzo_farmaco");
							
							DescrizioneFarmaco df = new DescrizioneFarmaco(nome, prescrizione, sintomi, eff_co, prezzo_f, num_serie);
							Farmaco f = new Farmaco(num_serie, quantita, df );
							int flag = 0;
							for(Farmaco fa : farmaci) {
								if(fa.getNumSerie().equals(f.getNumSerie()) ) {
									fa.setQuantita(fa.getQuantita() + f.getQuantita());
									flag = 1;
									break;
								}
							} 
							if(flag == 0) farmaci.add(f);
						}
					}
					OrdinePrenotato op;
					
					if(farmaci.isEmpty() == true) {
						OrdineConsulenza o = new OrdineConsulenza(cod_ordine, prezzo, or, or_rit, farmaci);
						 op = new OrdinePrenotato(o);
						 farmaci.removeAll(farmaci);
					}else {
						OrdineCompleto o = new OrdineCompleto(cod_ordine, prezzo, or, or_rit, farmaci);
						 op = new OrdinePrenotato(o);
						 farmaci.removeAll(farmaci);
					}
					
					op.setIdCliente(id_cliente);
					op.setPagato(pagato);
					
					ordini.add(op);
				}	
			}catch (SQLException e) {
				System.out.println("errore:" + e.getMessage());
		} catch (ParseException e) {
				
				e.printStackTrace();
			} 						
		// Chiusura connessione
		cn.close();
	}catch(SQLException e) {
		System.out.println("Errore nel caricamento dei dati dal database");
	}	
return ordini;
}


public void saveConsegnato(OrdineConsegnato o) {
	try {
		Connection cn;
		PreparedStatement st;
		
		
		// Connessione
		try {					
			Class.forName("com.mysql.jdbc.Driver");
		}catch(ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: ");
			System.out.println(e.getMessage());
		}
				
		// Si crea la connessione al Database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fapp?user=root&password=");
		
		st = cn.prepareStatement("INSERT INTO ORDINE_CONSEGNATO values(?,?,?,?,?,?,?)");
		st.setInt(1, o.getCodOrdine());
		st.setInt(2, o.getIdCliente());
		st.setFloat(3, o.getPrezzoOrdine());

		SimpleDateFormat formato_data = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss");
		String o1 = formato_data.format(o.getOrarioOrdine());
		//se l'ordine � a domicilio non ho un orario di ritiro
		st.setTimestamp(4, java.sql.Timestamp.valueOf(o1));
		if(o.getOrarioRitiro() == null) {
			st.setNull(5, 0);
		}
		else {
			String o2 = formato_data.format(o.getOrarioRitiro());
			st.setTimestamp(5, java.sql.Timestamp.valueOf(o2));
		}
		
		st.setBoolean(6, o.getPagato());
		st.setInt(7, o.getMetodo());
		st.executeUpdate();
		
		//SALVATAGGIO DEI FARMACI RELATIVI ALL'ORDINE
		for(Farmaco f : o.getFarmaciOrdinati()) {
			PreparedStatement st2 = cn.prepareStatement("INSERT INTO FARMACI_CONSEGNATI values(?,?,?,?)");
			PreparedStatement st3 = cn.prepareStatement("SELECT * FROM FARMACO f WHERE f.NUM_SERIE = ?");
			PreparedStatement st4 = cn.prepareStatement("UPDATE FARMACO far SET far.QUANTITA = ?" + " WHERE far.NUM_SERIE = ?");
				
			
			st2.setInt(1, o.getIdCliente());
			st2.setInt(2, o.getCodOrdine());
			st2.setString(3, f.getNumSerie());
			st2.setInt(4, f.getQuantita());
			
			st3.setString(1, f.getNumSerie());
			ResultSet rs = st3.executeQuery();
			int quantita = 0;
			while(rs.next() == true) {
				quantita = rs.getInt("Quantita");
			}
			st4.setInt(1, quantita - f.getQuantita());
			st4.setString(2, f.getNumSerie());
			st4.executeUpdate();
			st2.executeUpdate();
		}
		
		
		PreparedStatement st5 = cn.prepareStatement("DELETE FROM ORDINE_PRENOTATO WHERE CODICE_UT = ? and CODICE_ORDINE = ?");
		st5.setInt(1,o.getIdCliente());
		st5.setInt(2,o.getCodOrdine());
		st5.executeUpdate();
		
		PreparedStatement st6 = cn.prepareStatement("DELETE FROM FARMACI_ORDINATI WHERE ID_CLIENTE = ?");
		st6.setInt(1,o.getIdCliente());
		st6.executeUpdate();
		
		
		// Chiusura connessione
		cn.close();
	} catch (SQLException e) {
		System.out.println("errore:" + e.getMessage());
	}
}

public List<OrdineConsegnato> caricaConsegnati(Cliente c) {
	List<OrdineConsegnato> ordini = new ArrayList<>();
	
	try {
		Connection cn;
		PreparedStatement st;
		ResultSet rs;
		String sql;
		
		// Connessione
try {					
	Class.forName("com.mysql.jdbc.Driver");
}catch(ClassNotFoundException e) {
	System.out.println("ClassNotFoundException: ");
	System.out.println(e.getMessage());
}
		
// Si crea la connessione al Database
cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fapp?user=root&password=");
		

	try {
		// Si crea sempre uno Statement sulla connessione
		st = cn.prepareStatement("SELECT * FROM ORDINE_CONSEGNATO WHERE CODICE_UT = ?"); 
		st.setInt(1, c.getId());		
		// Si effettua la query su uno Statement
		rs = st.executeQuery();
				
		while (rs.next() == true) {
			List<Farmaco> farmaci = new ArrayList<>();
			int cod_ordine = rs.getInt("Codice_ordine");
			int id_cliente = rs.getInt("Codice_ut");
			float prezzo = rs.getFloat("Prezzo");
			Boolean pagato = rs.getBoolean("Pagato");
			int metodo = rs.getInt("Metodo");
			//conversione date dell'ordine
			String y = rs.getString("Orario_ordine").substring(0,4);
			String m = rs.getString("Orario_ordine").substring(5,7);
			String g = rs.getString("Orario_ordine").substring(8,10);
			String ora = rs.getString("Orario_ordine").substring(11,13);
			String min = rs.getString("Orario_ordine").substring(14,16);
			String orario_ordine = g + "." + m + "." + y + " " + ora + ":"+ min;
			SimpleDateFormat formato_data2 = new SimpleDateFormat ("dd.MM.yyyy HH:mm");
			
			Date or = new Date();
			or = formato_data2.parse(orario_ordine);
			
			//conversione date ritiro
			y = rs.getString("Orario_ritiro").substring(0,4);
			m = rs.getString("Orario_ritiro").substring(5,7);
			g = rs.getString("Orario_ritiro").substring(8,10);
			ora = rs.getString("Orario_ritiro").substring(11,13);
			min = rs.getString("Orario_ritiro").substring(14,16);
			String orario_ritiro = g + "." + m + "." + y + " " + ora + ":"+ min;
			
			Date or_rit = new Date();
			or_rit = formato_data2.parse(orario_ritiro);
			
			//caricamento farmaci relativi all'ordine
			PreparedStatement st2 = cn.prepareStatement("SELECT * FROM FARMACI_CONSEGNATI f WHERE f.ID_CLIENTE = ? AND f.COD_ORDINE = ?");
			st2.setInt(1, id_cliente);
			st2.setInt(2, cod_ordine);
			ResultSet rs2 = st2.executeQuery();
			
			while(rs2.next() == true) {
				String num_serie = rs2.getString("Num_serie_farm");
				int quantita = rs2.getInt("Quantita");
				//recupero descrizioni farmaco
				PreparedStatement st3 = cn.prepareStatement("SELECT * FROM DESC_FARMACO df WHERE df.NUM_SERIE = ?");
				st3.setString(1, num_serie);
				ResultSet rs3 = st3.executeQuery();
				while(rs3.next() == true) {
					String nome = rs3.getString("Nome");
					Boolean prescrizione = rs3.getBoolean("Prescrizione");
					String sintomi = rs3.getString("Sintomi");
					String eff_co = rs3.getString("Effetti_collaterali");
					Float prezzo_f = rs3.getFloat("Prezzo_farmaco");
					
					DescrizioneFarmaco df = new DescrizioneFarmaco(nome, prescrizione, sintomi, eff_co, prezzo_f, num_serie);
					Farmaco f = new Farmaco(num_serie, quantita, df );
					int flag = 0;
					for(Farmaco fa : farmaci) {
						if(fa.getNumSerie().equals(f.getNumSerie()) ) {
							fa.setQuantita(fa.getQuantita() + f.getQuantita());
							flag = 1;
							break;
						}
					} 
					if(flag == 0) farmaci.add(f);
				}
			}
			
			Ordine o = new Ordine(cod_ordine, prezzo, or, or_rit, farmaci);
			OrdinePrenotato op = new OrdinePrenotato(o);
			op.setPagato(pagato);
			op.setIdCliente(id_cliente);
			OrdineConsegnato oc = new OrdineConsegnato(op);
			oc.setPagatoDB(pagato);
			oc.setIdCliente(id_cliente);
			oc.setMetodo(metodo);
			ordini.add(oc);
		}	
	}catch (SQLException e) {
		System.out.println("errore:" + e.getMessage());
} catch (ParseException e) {
		
		e.printStackTrace();
	} 						
// Chiusura connessione
	cn.close();
}catch(SQLException e) {
	System.out.println("Errore nel caricamento dei dati dal database");
	}	
return ordini;
	
}

public void saveOrdineConsulenza(OrdinePrenotato o) {
	try {
		Connection cn;
		PreparedStatement st;
				
				
		// Connessione
		try {					
			Class.forName("com.mysql.jdbc.Driver");
		}catch(ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: ");
			System.out.println(e.getMessage());
		}
				
		// Si crea la connessione al Database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fapp?user=root&password=");
		
		st = cn.prepareStatement("UPDATE ORDINE_PRENOTATO op SET op.PREZZO = ?" + " WHERE op.CODICE_UT = ?");
		st.setFloat(1, o.getPrezzoOrdine());
		st.setInt(2, o.getIdCliente());
		st.executeUpdate();
		
		//SALVATAGGIO DEI FARMACI RELATIVI ALL'ORDINE
		if(o.getFarmaciOrdinati() != null) {
			for(Farmaco f : o.getFarmaciOrdinati()) {
				PreparedStatement st2 = cn.prepareStatement("INSERT INTO FARMACI_ORDINATI values(?,?,?)");
				st2.setInt(1, o.getIdCliente());
				st2.setString(2, f.getNumSerie());
				st2.setInt(3, f.getQuantita());
				st2.executeUpdate();
				}
			}
		
		// Chiusura connessione
					cn.close();
			
			} catch (SQLException e) {
				System.out.println("errore:" + e.getMessage());
			}
	}

public void setVenduto(OrdineConsegnato oc) {
	try {
		Connection cn;
		PreparedStatement st;
						
		// Connessione
		try {					
			Class.forName("com.mysql.jdbc.Driver");
		}catch(ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: ");
			System.out.println(e.getMessage());
		}
				
		// Si crea la connessione al Database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fapp?user=root&password=");
		
		st = cn.prepareStatement("UPDATE ORDINE_CONSEGNATO oc SET oc.PAGATO = ?, oc.METODO = ?" + " WHERE oc.CODICE_UT = ? AND oc.CODICE_ORDINE = ?");
		st.setBoolean(1, true);
		st.setInt(2, oc.getMetodo());
		st.setInt(3, oc.getIdCliente());
		st.setInt(4, oc.getCodOrdine());
		st.executeUpdate();
		
		// Chiusura connessione
					cn.close();
			
			} catch (SQLException e) {
				System.out.println("errore:" + e.getMessage());
			}
	
}
			
}

	
