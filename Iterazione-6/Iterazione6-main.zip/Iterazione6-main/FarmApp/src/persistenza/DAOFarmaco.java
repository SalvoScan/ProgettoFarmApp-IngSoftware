package persistenza;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import dominio.*;

	public class DAOFarmaco {
		private static DAOFarmaco singleton;
		
		public static synchronized DAOFarmaco getInstance(){
			if (singleton == null)
				singleton = new DAOFarmaco();
			return singleton;
		}

		public void saveFarmaco(Farmaco f) {
				List<Farmaco> farmaci = new ArrayList<>();
				farmaci = caricaFar();
				int flag = 0;
				try {
					Connection cn;
					PreparedStatement st;
					
					// Connessione
					try {					
						Class.forName("com.mysql.jdbc.Driver");
					}catch(ClassNotFoundException e) {
						System.out.println("ClassNotFoundException: ");
						System.out.println(e.getMessage());
					}
							
					// Si crea la connessione al Database
					cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fapp?user=root&password=");
							
					// QUERY SUL DB	
					
						try {
							for(Farmaco fa : farmaci) {
								if(fa.getNumSerie().equals(f.getNumSerie())) {
									System.out.println(f.getQuantita());
									st = cn.prepareStatement("UPDATE FARMACO SET QUANTITA = ? "+"WHERE NUM_SERIE = ?");
									System.out.println(f.getQuantita());
									System.out.println(f.getNumSerie());
									st.setInt(1, f.getQuantita());
									st.setString(2, f.getNumSerie());
									st.executeUpdate();
									
									flag = 1;
									break;
								}
							}
							if (flag == 0) {
								st = cn.prepareStatement("INSERT INTO Farmaco values(?,?)");
								st.setString(1, f.getNumSerie());
								st.setInt(2, f.getQuantita());
								st.executeUpdate();
							}		
							
						}catch (SQLException e) {
							System.out.println("errore:" + e.getMessage());
				} 					
					// Chiusura connessione
					cn.close();
				}catch(SQLException e) {
					System.out.println("Errore nel caricamento dei dati dal database");
				}	
	}

		public List<Farmaco> caricaFar(){
			List<Farmaco> farmaci = new ArrayList<>();
			try {
				Connection cn;
				Statement st;
				ResultSet rs;
				String sql;
				
				// Connessione
				try {					
					Class.forName("com.mysql.jdbc.Driver");
				}catch(ClassNotFoundException e) {
					System.out.println("ClassNotFoundException: ");
					System.out.println(e.getMessage());
				}
						
				// Si crea la connessione al Database
				cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fapp?user=root&password=");
						
				// QUERY SUL DB	
				sql = "SELECT * FROM FARMACO f JOIN DESC_FARMACO df on f.NUM_SERIE = df.NUM_SERIE";
					try {
						// Si crea sempre uno Statement sulla connessione
						st = cn.createStatement(); 
								
						// Si effettua la query su uno Statement
						rs = st.executeQuery(sql);
								
						while (rs.next() == true) {
							String num_serie = rs.getString("Num_serie");
							int quantita = rs.getInt("Quantita");
							String nome = rs.getString("Nome");
							Boolean prescrizione = rs.getBoolean("Prescrizione");
							String sintomi = rs.getString("Sintomi");
							String eff_co = rs.getString("Effetti_collaterali");
							Float prezzo = rs.getFloat("Prezzo_farmaco");
							
							DescrizioneFarmaco df = new DescrizioneFarmaco(nome, prescrizione, sintomi, eff_co, prezzo, num_serie);
							
							Farmaco f = new Farmaco(num_serie, quantita, df );
							farmaci.add(f);
						}	
					}catch (SQLException e) {
						System.out.println("errore:" + e.getMessage());
				} 						
				// Chiusura connessione
				cn.close();
			}catch(SQLException e) {
				System.out.println("Errore nel caricamento dei dati dal database");
			}	
			return farmaci;
		}
					
}
