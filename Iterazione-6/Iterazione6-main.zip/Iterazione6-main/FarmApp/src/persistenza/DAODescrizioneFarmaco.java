package persistenza;
import java.sql.*;

import java.util.*;


import dominio.*;

public class DAODescrizioneFarmaco {
	private static DAODescrizioneFarmaco singleton;
	
	public static synchronized DAODescrizioneFarmaco getInstance(){
		if (singleton == null)
			singleton = new DAODescrizioneFarmaco();
		return singleton;
	}

	public List<DescrizioneFarmaco> selectFarmaci() {
			List<DescrizioneFarmaco> d_farmaci = new ArrayList<>();
			try {
				Connection cn;
				Statement st;
				ResultSet rs;
				String sql;
				
				// Connessione
				try {					
					Class.forName("com.mysql.jdbc.Driver");
				}catch(ClassNotFoundException e) {
					System.out.println("ClassNotFoundException: ");
					System.out.println(e.getMessage());
				}
						
				// Si crea la connessione al Database
				cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fapp?user=root&password=");
						
				// QUERY SUL DB	
				sql = "SELECT * FROM DESC_FARMACO";
					try {
						// Si crea sempre uno Statement sulla connessione
						st = cn.createStatement(); 
								
						// Si effettua la query su uno Statement
						rs = st.executeQuery(sql);
								
						while (rs.next() == true) {
							String num_serie = rs.getString("Num_serie");
							String nome = rs.getString("Nome");
							Boolean prescrizione = rs.getBoolean("Prescrizione");
							String sintomi = rs.getString("Sintomi");
							String eff_co = rs.getString("Effetti_collaterali");
							Float prezzo = rs.getFloat("Prezzo_farmaco");
							
							DescrizioneFarmaco df = new DescrizioneFarmaco(nome, prescrizione, sintomi, eff_co, prezzo, num_serie);
							d_farmaci.add(df);
						}	
					}catch (SQLException e) {
						System.out.println("errore:" + e.getMessage());
				} 						
				// Chiusura connessione
				cn.close();
			}catch(SQLException e) {
				System.out.println("Errore nel caricamento dei dati dal database");
			}	
			return d_farmaci;
}

	
	
}