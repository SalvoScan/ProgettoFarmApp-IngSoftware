package persistenza;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

import dominio.*;

public class DAOCliente {
	private static DAOCliente singleton;
	
	public static synchronized DAOCliente getInstance(){
		if (singleton == null)
			singleton = new DAOCliente();
		return singleton;
	}
	//funzione per caricare i clienti registrati dal database all'applicazione
	public List<Cliente> selectClienti(){
		List<Cliente> clienti = new ArrayList<>();
		try {
			Connection cn;
			Statement st;
			ResultSet rs;
			String sql;
			
			// Connessione
			try {					
				Class.forName("com.mysql.jdbc.Driver");
			}catch(ClassNotFoundException e) {
				System.out.println("ClassNotFoundException: ");
				System.out.println(e.getMessage());
			}
					
			// Si crea la connessione al Database
			cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fapp?user=root&password=");
					
			// QUERY SUL DB	
			sql = "SELECT * FROM Cliente c JOIN Account a on c.ID = a.ID_UT ORDER BY ID_UT;";
				try {
					// Si crea sempre uno Statement sulla connessione
					st = cn.createStatement(); 
							
					// Si effettua la query su uno Statement
					rs = st.executeQuery(sql);
							
					while (rs.next() == true) {
						String iden = rs.getString("Id");
						int id = Integer.parseInt(iden);
								
						String email = rs.getString("Email");
						
						String password = rs.getString("Password");
						
						String nome = rs.getString("Nome");
						String cognome = rs.getString("Cognome");
						String data_nascita = rs.getString("Data_nascita");
						String codice_fiscale = rs.getString("Codice_fiscale");
						String indirizzo =  rs.getString("Indirizzo");
						PreparedStatement st2 = cn.prepareStatement("SELECT * FROM Carta_di_credito cc WHERE COD_FISCALE = ?");
						st2.setString(1, codice_fiscale);
						ResultSet rs2 = st2.executeQuery();
						Account a = new Account(nome, cognome, data_nascita, codice_fiscale, indirizzo);
						while (rs2.next() == true) {
							if(rs2 != null) {
								long iban = Long.parseLong(rs2.getString("Iban"));
								String y_scadenza = rs2.getString("Scadenza").substring(0,4);
								String m_scadenza = rs2.getString("Scadenza").substring(5,7);
								String g_scadenza = rs2.getString("Scadenza").substring(8,10);
								String scadenza = g_scadenza + "." +  m_scadenza +"." +  y_scadenza;
								SimpleDateFormat formato_data2 = new SimpleDateFormat ("dd.MM.yyyy");
								
								Date sc = new Date();
								sc = formato_data2.parse(scadenza);
							
								CartaCredito cc = new CartaCredito(iban , sc, rs2.getString("nome_intestatario"), rs2.getString("cognome_intestatario"));
								a.setCartaCredito(cc);
							}
							
						}	
							Cliente c = new Cliente(email, password, a);
							c.setId(id);
							clienti.add(c);							
						
					}
				}catch (SQLException e) {
					System.out.println("errore:" + e.getMessage());
			} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
					
			// Chiusura connessione
			cn.close();
		}catch(SQLException e) {
			System.out.println("Errore nel caricamento dei dati dal database");
		}	
		return clienti;
	}

	public void saveCliente(Cliente c) {
		try {
			Connection cn;
			PreparedStatement st;
			
			try {					
				Class.forName("com.mysql.jdbc.Driver");
			}catch(ClassNotFoundException e) {
				System.out.println("ClassNotFoundException: ");
				System.out.println(e.getMessage());
			}
			
			cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fapp?user=root&password=");
			
			try {
				//inserimento del cliente
				st = cn.prepareStatement("INSERT INTO CLIENTE values (?, ?, ?)");
				int id = c.getId();
				String email = c.getEmail();
				String password = c.getPassword();
			
				st.setInt(1, id);
				st.setString(2,	email);
				st.setString(3, password);
				st.executeUpdate();
				
				//inserimento account
				
				String cod_fiscale = c.getAccount().getCodiceFiscale();
				String nome = c.getAccount().getNome();
				String cognome = c.getAccount().getCognome();
				String data_n = c.getAccount().getDataNascita();
				String indirizzo = c.getAccount().getIndirizzo();
				
				st = cn.prepareStatement("INSERT INTO ACCOUNT values (?, ?, ?, ?, ?, ?)");
				st.setString(1,	cod_fiscale);
				st.setString(2,	nome);
				st.setString(3, cognome);
				st.setString(4, data_n);
				st.setString(5, indirizzo);
				st.setInt(6, id);
				st.executeUpdate();
						
			}catch (SQLException e) {
				System.out.println("errore:" + e.getMessage());
			}finally {
				cn.close();
			}
			
		}catch(SQLException e) {
			System.out.println("Errore nel caricamento dei dati nel database");
		}
	}
}
