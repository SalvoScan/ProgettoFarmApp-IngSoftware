package persistenza;
import java.sql.*;


import dominio.*;

public class DAOCartaCredito {
	private static DAOCartaCredito singleton;
	
	public static synchronized DAOCartaCredito getInstance(){
		if (singleton == null)
			singleton = new DAOCartaCredito();
		return singleton;
	}

	public void saveCartaCredito(CartaCredito cc, Cliente c) {
			
			try {
				Connection cn;
				PreparedStatement st;
				
				// Connessione
				try {					
					Class.forName("com.mysql.jdbc.Driver");
				}catch(ClassNotFoundException e) {
					System.out.println("ClassNotFoundException: ");
					System.out.println(e.getMessage());
				}
						
				// Si crea la connessione al Database
				cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fapp?user=root&password=");
						
				// QUERY SUL DB	
				
					try {
						
						st = cn.prepareStatement("INSERT INTO Carta_di_Credito values(?,?,?,?,?)");
						String scadenza = cc.getScadenza();
						String s = scadenza.substring(6,10) +"-"+scadenza.substring(3,5) +"-"+ scadenza.substring(0,2);
					
						st.setLong(1, cc.getCodIBAN());
						st.setDate(2, java.sql.Date.valueOf(s));
						st.setString(3, cc.getNomeIntestatario());
						st.setString(4, cc.getCognomeIntestatario());
						st.setString(5, c.getAccount().getCodiceFiscale());
						st.executeUpdate();
								
						
					}catch (SQLException e) {
						System.out.println("errore:" + e.getMessage());
			} 					
				// Chiusura connessione
				cn.close();
			}catch(SQLException e) {
				System.out.println("Errore nel caricamento dei dati dal database");
			}	
}

	
	
}