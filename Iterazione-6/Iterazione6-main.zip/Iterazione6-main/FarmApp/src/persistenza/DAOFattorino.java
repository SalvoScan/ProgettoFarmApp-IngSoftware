package persistenza;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import dominio.*;

public class DAOFattorino {
private static DAOFattorino singleton;
	
	public static synchronized DAOFattorino getInstance(){
		if (singleton == null)
			singleton = new DAOFattorino();
		return singleton;
	}
	//funzione per caricare i farmacisti registrati dal database all'applicazione
	public Fattorino selectFattorino(){
		Fattorino fattorino = null;
		try {
			Connection cn;
			Statement st;
			ResultSet rs;
			String sql;
			
			// Connessione
			try {			
				Class.forName("com.mysql.jdbc.Driver");
			}catch(ClassNotFoundException e) {
				System.out.println("ClassNotFoundException: ");
				System.out.println(e.getMessage());
			}
					
			// Si crea la connessione al Database
			cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fapp?user=root&password=");
					
			// QUERY SUL DB	
			sql = "SELECT * FROM Fattorino;";
				// Si crea sempre uno Statement sulla connessione
				st = cn.createStatement(); 
						
				// Si effettua la query su uno Statement
				rs = st.executeQuery(sql);
				
				
				while (rs.next() == true) {
					int id = rs.getInt("Id");		
					String email = rs.getString("Email");
					String password = rs.getString("Password");
					fattorino = new Fattorino(id, email, password);
				}
					
			// Chiusura connessione
			cn.close();
		}catch(SQLException e) {
			System.out.println("Errore nel caricamento dei dati dal database");
		}	
		return fattorino;
	}
}
