package persistenza;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import dominio.*;

public class DAOFarmacista {
private static DAOFarmacista singleton;
	
	public static synchronized DAOFarmacista getInstance(){
		if (singleton == null)
			singleton = new DAOFarmacista();
		return singleton;
	}
	//funzione per caricare i farmacisti registrati dal database all'applicazione
	public List<Farmacista> selectFarmacista(){
		List<Farmacista> farmacista = new ArrayList<>();
		try {
			Connection cn;
			Statement st;
			ResultSet rs;
			String sql;
			
			// Connessione
			try {			
				Class.forName("com.mysql.jdbc.Driver");
			}catch(ClassNotFoundException e) {
				System.out.println("ClassNotFoundException: ");
				System.out.println(e.getMessage());
			}
					
			// Si crea la connessione al Database
			cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fapp?user=root&password=");
					
			// QUERY SUL DB	
			sql = "SELECT * FROM Farmacista;";
				// Si crea sempre uno Statement sulla connessione
				st = cn.createStatement(); 
						
				// Si effettua la query su uno Statement
				rs = st.executeQuery(sql);
						
				while (rs.next() == true) {
					int id = rs.getInt("Id");		
					String email = rs.getString("Email");
					String password = rs.getString("Password");
					Farmacista farm = new Farmacista (id, email, password);
					farmacista.add(farm);
				}
					
			// Chiusura connessione
			cn.close();
		}catch(SQLException e) {
			System.out.println("Errore nel caricamento dei dati dal database");
		}	
		return farmacista;
	}
}
