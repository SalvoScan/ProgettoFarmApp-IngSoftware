insert into Cliente values (1, 'saro@live.it', 'saglimbene');
insert into Cliente values (2, 'nunzio@alice.it', 'saitta');

insert into Account values ('SGS100', 'rosario', 'saglimbene', '20.06.1997', 'via Etnea', 1);
insert into Account values ('GGN1000', 'nunzio', 'saitta', '25.12.0000', 'via dei Re Magi', 2);

insert into Farmacista values (12, 'saro@hotmail.it', 'saro');

insert into Amministratore values (26, 'salvo@gmail.com', 'salvo');

insert into Fattorino values (30, 'nunzio@alice', 'nunzio');

insert into DESC_FARMACO values ('030681260', 'Advantan', false, 'Trattamento di eczemi, dermatiti a carattere infiammatorio', 'Bruciore, prurito, secchezza, eritema, vescicole', 7.50);
insert into DESC_FARMACO values ('042950274', 'VivinC', false, 'Mal di testa/denti, nevralgie, dolori reumatici', 'Nausea, vomito, diarrea, flatulenza, costipazione, dolore addominale', 8.90);
insert into DESC_FARMACO values ('108814425', 'Aulin', false, 'Dolore acuto/mestruale, antinfiammatorio', 'Diarrea, nausea, vomito, respiro corto, vertigini, prurito, eruzioni cutanee', 4.43);
insert into DESC_FARMACO values ('030681264', 'Medrol', true, 'Malattie articolazioni/pelle/occhi/polmoni/sangue/intestino/cervello', 'Infezioni, gonfiore viso/lingua/gola, faccia rotonda', 6.20);
insert into DESC_FARMACO values ('038894449', 'Zimox', true, 'Antibiotico, infezioni acute/orecchio/naso/gola/rene/vescica', 'Reazione allergica, gonfiore e prurito del viso, stanchezza, sudorazione abbondante', 4.90);
insert into DESC_FARMACO values ('000614721', 'Imodium', false, 'Diarrea occasionale acuta', 'Mal di testa, capogiri, sonnolenza, nausea, eruzione della cute, contrazione della pupilla', 7.00);
insert into DESC_FARMACO values ('021636625', 'Plasil', true, 'Prevenzione nausea e vomito, emicrania acuta', 'Movimenti incontrollabili, febbre alta, pressione alta, convulsioni, sudorazione', 8.00);
insert into DESC_FARMACO values ('016666477', 'Tachipirina', false, 'Sintomi febbrili, antipiretico, nevralgie, mialgie', 'Anemia, agranulocitosi, orticaria, shock anafilattico, vertigini', 6.50);
insert into DESC_FARMACO values ('008013028', 'Spasmex', true, 'Contrazioni dolorose e improvvise delle vie urinarie e biliari', 'Reazioni allergiche', 7.95);
insert into DESC_FARMACO values ('006281149', 'Algix', true, 'Dolore e gonfiore delle articolazioni, artrosi, reumatoide, gotta', 'Respiro affannoso, dolori toracici, dolore stomaco, capogiro, palpitazioni', 11.01);

insert into CARTA_DI_CREDITO values('554422123131', '2022.12.12', 'nunzio', 'saitta', 'GGN1000');