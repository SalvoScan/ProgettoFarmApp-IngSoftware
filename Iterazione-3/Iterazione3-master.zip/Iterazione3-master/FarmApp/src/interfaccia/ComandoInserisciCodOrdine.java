package interfaccia;

import dominio.*;
import java.util.*;

public class ComandoInserisciCodOrdine implements Comando {
	public static final String codiceComando = "1";
	public static final String descrizioneComando = "Inserisci il codice dell'ordine";
	
	public String getCodiceComando() {
		return codiceComando;
	}

	public String getDescrizioneComando() {
		return descrizioneComando;
	}

	public void esegui(FarmApp farmapp) {
		List<OrdineConsegnato> ordini_consegnati = farmapp.getClienteAlBanco().getOrdiniConsegnati();
		OrdineConsegnato oc = ordini_consegnati.get(ordini_consegnati.size() - 1);
		
		System.out.println("INFO ORDINE SELEZIONATO");
		System.out.println(oc);
	}
}
