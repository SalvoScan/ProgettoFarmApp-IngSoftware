package interfaccia;

import java.util.List;

import dominio.FarmApp;
import dominio.Farmaco;
import dominio.Inventario;

public class ComandoVisualizzaInventario implements Comando{
	public static final String codiceComando = "1";
	public static final String descrizioneComando = "Visualizza lista farmaci";
	
	public String getCodiceComando() {
		return codiceComando;
	}

	public String getDescrizioneComando() {
		return descrizioneComando;
	}

	public void esegui(FarmApp farmapp) {
		System.out.println("Elenco dei farmaci:");
		Inventario i =  farmapp.getInventario();
		farmapp.setInventarioCorrente(i.getListaFarmaci());
		i.stampaListaFarmaci();
	}
}
