package interfaccia;

import java.util.List;

import dominio.FarmApp;
import dominio.OrdineConsegnato;

public class ComandoConfermaPagamento implements Comando {
	public static final String codiceComando = "3";
	public static final String descrizioneComando = "Conferma il pagamento";
	
	public String getCodiceComando() {
		return codiceComando;
	}

	public String getDescrizioneComando() {
		return descrizioneComando;
	}

	public void esegui(FarmApp farmapp) {
		List<OrdineConsegnato> ordini_consegnati = farmapp.getClienteAlBanco().getOrdiniConsegnati();
		OrdineConsegnato oc = ordini_consegnati.get(ordini_consegnati.size() - 1);
		
		oc.setPagato(true);
		
		System.out.println("L'ordine � stato pagato correttamente");
		
		farmapp.setRegistroVendite(oc);
		
		System.out.println("STAMPA DELLA RICEVUTA IN CORSO . . . ");
	}
}
