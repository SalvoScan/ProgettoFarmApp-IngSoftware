package interfaccia;

import java.util.List;

import dominio.FarmApp;
import dominio.Farmaco;

public class ComandoSelezionaFarmaco implements Comando{
	public static final String codiceComando = "2";
	public static final String descrizioneComando = "Seleziona un farmaco";
	
	public String getCodiceComando() {
		return codiceComando;
	}
	
	public String getDescrizioneComando() {
		return descrizioneComando;
	}
	
	public void esegui(FarmApp farmapp) {
		System.out.println("Inserisci il codice del farmaco: ");
		String num_serie = Parser.getInstance().read();
		List<Farmaco> farmaci =  farmapp.getInventarioCorrente();
		for (Farmaco f: farmaci){
		if(num_serie.equals(f.getNumSerie())) {
			System.out.println(f + "\n");
			System.out.println(f.getDescrizioneFarmaco());
		  }
		}
	}
}
