package interfaccia;

import java.util.List;

import dominio.FarmApp;
import dominio.OrdineConsegnato;

public class ComandoSelezionaPagamento implements Comando {
	public static final String codiceComando = "2";
	public static final String descrizioneComando = "Selezionare metodo di pagamento";
	
	public String getCodiceComando() {
		return codiceComando;
	}

	public String getDescrizioneComando() {
		return descrizioneComando;
	}

	public void esegui(FarmApp farmapp) {
		List<OrdineConsegnato> ordini_consegnati = farmapp.getClienteAlBanco().getOrdiniConsegnati();
		OrdineConsegnato oc = ordini_consegnati.get(ordini_consegnati.size() - 1);
		
		System.out.println("Inserire il metodo di pagamento");
		System.out.println("0 -> carta di credito");
		System.out.println("1 -> contanti");
		
		String met = Parser.getInstance().read();
		int metodo = Integer.parseInt(met);
		
		if(metodo == 1) {
			oc.setMetodo(metodo);
			System.out.println("RIEPILOGO ORDINE");
			System.out.println("Nome : "+farmapp.getClienteAlBanco().getAccount().getNome());
			System.out.println("Cognome : "+farmapp.getClienteAlBanco().getAccount().getCognome());
			System.out.println("Codice Ordine : "+oc.getCodOrdine());
			System.out.println("Pagato con contanti");
			return;
		}
		if(metodo == 0) {
			if(farmapp.getClienteAlBanco().getAccount().getCartaCredito() == null) {
				System.out.println("Carta di credito non registrata");
				System.out.println("Richiesto pagamento in contanti");
				oc.setMetodo(1);
				System.out.println("RIEPILOGO ORDINE");
				System.out.println("Nome : "+farmapp.getClienteAlBanco().getAccount().getNome());
				System.out.println("Cognome : "+farmapp.getClienteAlBanco().getAccount().getCognome());
				System.out.println("Codice Ordine : "+oc.getCodOrdine());
				System.out.println("Pagato con contanti");
				return;
			}else {
				oc.setMetodo(metodo);
				System.out.println("RIEPILOGO ORDINE");
				System.out.println("Nome : "+farmapp.getClienteAlBanco().getAccount().getNome());
				System.out.println("Cognome : "+farmapp.getClienteAlBanco().getAccount().getCognome());
				System.out.println("Codice Ordine : "+oc.getCodOrdine());
				System.out.println("Pagato con carta di credito");
				return;
			}
		}
	}
}
