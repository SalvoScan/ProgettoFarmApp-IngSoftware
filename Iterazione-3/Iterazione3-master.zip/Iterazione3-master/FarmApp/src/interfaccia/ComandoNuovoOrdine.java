package interfaccia;

import java.util.*;

import dominio.*;


public class ComandoNuovoOrdine implements Comando {
	public static final String codiceComando = "1";
	public static final String descrizioneComando = "Lista dei farmaci ordinabili";
	
	public String getCodiceComando() {
		return codiceComando;
	}

	public String getDescrizioneComando() {
		return descrizioneComando;
	}

	public void esegui(FarmApp farmapp) {
		Cliente cl_autenticato = farmapp.getClienteAutenticato();
		if(cl_autenticato.getOrdinePrenotato() != null) {
			System.out.println("Esiste gi� una prenotazione attualmente in corso!");
			return;
		}
		
		System.out.println("Elenco dei farmaci:");
		Inventario i =  farmapp.getInventario();
		farmapp.setInventarioCorrente(i.getListaFarmaci());
		i.stampaListaFarmaci();
	}
}
