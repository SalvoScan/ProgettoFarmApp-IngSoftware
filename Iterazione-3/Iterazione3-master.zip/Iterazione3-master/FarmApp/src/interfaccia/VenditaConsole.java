package interfaccia;

import dominio.FarmApp;

public class VenditaConsole {
	public void start(FarmApp fapp) throws Exception {
		stampaBenvenuto();
		Comando comando = Parser.getInstance().getComando(ElencoComandi.VENDITA);
		while (!comando.getCodiceComando().equals("0")) {
			comando.esegui(fapp);
			System.out.println();
			stampaBenvenuto();
			comando = Parser.getInstance().getComando(ElencoComandi.VENDITA);
		}
		comando.esegui(fapp); 
	}

    private void stampaBenvenuto() {
        System.out.println("VENDITA");
		System.out.println(ElencoComandi.elencoTuttiComandi(ElencoComandi.VENDITA));
		System.out.println("FAI LA TUA SCELTA");
	}
}
