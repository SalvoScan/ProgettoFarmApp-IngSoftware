package interfaccia;

import dominio.*;
import java.util.*;

public class ComandoConfermaFarmaco implements Comando{
	public static final String codiceComando = "2";
	public static final String descrizioneComando = "Conferma nuovo farmaco";
	
	public String getCodiceComando() {
		return this.codiceComando;
	}
	
	public String getDescrizioneComando() {
		return this.descrizioneComando;
	}
	
	public void esegui(FarmApp fapp) {
		Farmaco farmaco_corrente = fapp.getFarmacoCorrente();
		
		Inventario i = fapp.getInventario();
		List<Farmaco> lf = i.getListaFarmaci();
		
		for(Farmaco f : lf) {
			if(farmaco_corrente.getNumSerie().equals(f.getNumSerie())) {
				f.setQuantita(farmaco_corrente.getQuantita());
				System.out.println("Operazione Terminata");
				return;
			}
		}
		
		fapp.setInventario(farmaco_corrente);
		System.out.println("Operazione Terminata");
		
	}
	
	
}
