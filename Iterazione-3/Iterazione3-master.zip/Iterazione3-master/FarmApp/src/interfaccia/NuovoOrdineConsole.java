package interfaccia;

import dominio.*;

public class NuovoOrdineConsole {
	public void start(FarmApp fapp) throws Exception {
		stampaBenvenuto();
		Comando comando = Parser.getInstance().getComando(ElencoComandi.INSERISCI_NUOVO_ORDINE);
		while (!comando.getCodiceComando().equals("0")) {
			comando.esegui(fapp);
			System.out.println();
			stampaBenvenuto();
			comando = Parser.getInstance().getComando(ElencoComandi.INSERISCI_NUOVO_ORDINE);
		}
		comando.esegui(fapp); 
	}

    private void stampaBenvenuto() {
        System.out.println("NUOVO ORDINE");
		System.out.println(ElencoComandi.elencoTuttiComandi(ElencoComandi.INSERISCI_NUOVO_ORDINE));
		System.out.println("FAI LA TUA SCELTA");
	}
}
