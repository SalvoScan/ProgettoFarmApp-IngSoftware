package interfaccia;

import dominio.*;
import java.util.*;

public class ComandoConfermaDatiCarta implements Comando{
	public static final String codiceComando = "2";
	public static final String descrizioneComando = "Conferma carta di credito";
	
	public String getCodiceComando() {
		return this.codiceComando;
	}
	
	public String getDescrizioneComando() {
		return this.descrizioneComando;
	}
	
	public void esegui(FarmApp fapp) {
		CartaCredito carta_credito_corrente = fapp.getCartaCreditoCorrente();
		
		for(Cliente c : fapp.getListaClienti()) {
			if(c.getId() == fapp.getClienteAutenticato().getId()) {
				c.getAccount().setCartaCredito(carta_credito_corrente);
			}
		}	
		//Viene associata la carta di credito corrente all'account del cliente
		
		System.out.println("Operazione Terminata");
		
	}
	
	
}