package interfaccia;

import java.util.List;

import dominio.*;

public class ComandoSelezionaOrdine implements Comando{
	public static final String codiceComando = "2";
	public static final String descrizioneComando = "Seleziona ordine";
	
	public String getCodiceComando() {
		return codiceComando;
	}
	
	public String getDescrizioneComando() {
		return descrizioneComando;
	}
	
	public void esegui(FarmApp farmapp) {
		Cliente cl_autenticato = farmapp.getClienteAutenticato();
		List<OrdineConsegnato> storico_ordini = cl_autenticato.getOrdiniConsegnati();
		System.out.println("Inserisci il codice dell'ordine: ");
		String c_ordine = Parser.getInstance().read();
		int cod_ordine = Integer.parseInt(c_ordine);
		for(OrdineConsegnato oc : storico_ordini) {
			if(oc.getCodOrdine() == cod_ordine) {
				farmapp.setOrdineSelezionato(oc);
				System.out.println(oc.toString());
				return;
			}
		}
		System.out.println("Codice errato!");
	}
}
