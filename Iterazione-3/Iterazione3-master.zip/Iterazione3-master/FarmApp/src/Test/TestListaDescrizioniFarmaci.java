package Test;

import static org.junit.jupiter.api.Assertions.*;

import dominio.*;
import interfaccia.*;

import java.util.*;

import org.junit.jupiter.api.Test;

class TestListaDescrizioniFarmaci {
	FarmApp fapp = new FarmApp ();

	@Test
	void testListaDescrizioniFarmaci() {
		List<DescrizioneFarmaco> df = fapp.getInventario().getListaDescrizioniFarmaci();
		
		assertEquals("Vivinc", df.get(0).getNome());
	}

}
