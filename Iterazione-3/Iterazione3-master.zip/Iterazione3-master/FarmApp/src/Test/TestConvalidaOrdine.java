package Test;

import static org.junit.jupiter.api.Assertions.*;
import dominio.*;
import org.junit.jupiter.api.Test;

class TestConvalidaOrdine {
	FarmApp fapp = new FarmApp();

	@Test
	void test() {
		OrdinePrenotato op = fapp.getClienteAutenticato().getOrdinePrenotato();
		OrdineConsegnato oc = new OrdineConsegnato(op);
		
		fapp.getClienteAutenticato().setOrdiniConsegnati(oc);
		//verifichiamo che nella lista degli ordini consegnati sia stato aggiunto proprio l'ordine prenotato tramite cod ordine
		assertEquals(10, fapp.getClienteAutenticato().getOrdiniConsegnati().get(0).getCodOrdine());
	}

}
