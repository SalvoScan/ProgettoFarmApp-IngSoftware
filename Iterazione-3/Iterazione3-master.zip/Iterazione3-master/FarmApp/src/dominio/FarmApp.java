package dominio;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class FarmApp {
	private Inventario inventario;
	private List<String> orari = new ArrayList<String>();
	private List<Cliente> lista_clienti;
	private List<OrdinePrenotato> ordini_prenotati;
	private RegistroVendite registro_vendite;
	
	
	//Attributi per i Comandi
	
	private Farmaco farmaco_corrente;
	private CartaCredito carta_credito_corrente;
	private Cliente cliente_autenticato;
	private Cliente cliente_corrente;
	private List<Farmaco> inventario_corrente;
	private List<Farmaco> farmaci_ordine_corrente = new ArrayList<Farmaco>();
	private float prezzo_ordine_corrente = 0;
	private OrdinePrenotato ordine_prenotato_corrente;
	private Cliente cliente_albanco;
	//private int cod_ordine_selezionato = 0;
	private OrdineConsegnato ordine_selezionato_corrente;
	
	
	//Costruttore
	public FarmApp() {
		this.inventario = new Inventario();
		this.lista_clienti = new ArrayList<Cliente>();
		this.ordini_prenotati = new ArrayList<OrdinePrenotato>();
		this.registro_vendite = new RegistroVendite();
		caricaDatiProva();
	}
	
	/* Carica dei dati iniziali di prova. */ 
	private void caricaDatiProva() {
		caricaDescrizioniFarmaci();
		caricaClienti();
		caricaFarmaci();
		caricaListaOrari();
		caricaOrdini();
		System.out.println("Dati caricati");
	}

	/* inizializza il catalogo delle descrizioni dei farmaci */
	private void caricaDescrizioniFarmaci() {
		this.inventario.setNuovaDescrizioneFarmaco(new DescrizioneFarmaco("Vivinc", false, "mal di testa", "morte", 20, "12345"));
		this.inventario.setNuovaDescrizioneFarmaco(new DescrizioneFarmaco("Oki", false, "mal di testa", "morte", 20, "67890"));
		this.inventario.setNuovaDescrizioneFarmaco(new DescrizioneFarmaco("Oki task", false, "mal di testa", "morte", 20, "23456"));
		this.inventario.setNuovaDescrizioneFarmaco(new DescrizioneFarmaco("Tachipirina", false, "mal di testa", "morte", 20, "98765"));
	}
	
	private void caricaFarmaci() {
		DescrizioneFarmaco df = this.inventario.getListaDescrizioniFarmaci().get(0);
		this.inventario.setNuovoFarmaco(new Farmaco("12345", 3, df));
	}


	/* inizializza i clienti */
	private void caricaClienti() {
		
		Account a1 = new Account("salvo", "scandura", "30-02-2020", "sssssssss", "via orto dei limoni");
		
		try {
			String scadenza = "08.10.2025";
			SimpleDateFormat formato_data2 = new SimpleDateFormat ("dd.MM.yyyy");
			Date sc = new Date();
			sc = formato_data2.parse(scadenza);
			CartaCredito cc1 = new CartaCredito(54321, sc, "simone", "falsaperla");
			a1.setCartaCredito(cc1);
		}catch(ParseException e) {
			System.out.println("ParseException occured: " + e.getMessage());
		}
		
		Cliente c1 = new Cliente("salvo@gmail.com", "123456", a1);
		this.lista_clienti.add(c1);
		
		Account a2 = new Account("saro", "saglimbene", "30-02-2020", "sssssssss", "via carducci");
		Cliente c2 = new Cliente("saro@gmail.com", "1234567890", a2);
		this.lista_clienti.add(c2);
		Account a3 = new Account("nunzio", "saitta", "30-02-2020", "sssssssss", "via fusco");
		Cliente c3 = new Cliente("nunzio@gmail.com", "12345678", a3);
		this.lista_clienti.add(c3);
		this.cliente_autenticato = c1;
	}
	
	/* Inizializza la lista gli orari */
	private void caricaListaOrari() {
		for (int i = 10; i <= 20; i++) {
			this.orari.add(String.valueOf(i) + ":00");
			this.orari.add(String.valueOf(i) + ":15");
			this.orari.add(String.valueOf(i) + ":30");
			this.orari.add(String.valueOf(i) + ":45");
		}
	}
		
	private void caricaOrdini() {
			Ordine ordine = new Ordine(10, 20, new Date(), new Date(), this.inventario.getListaFarmaci());
			OrdinePrenotato ordine_prenotato = new OrdinePrenotato(ordine);
			this.cliente_autenticato.setOrdinePrenotato(ordine_prenotato);
	}
	//Metodi GETTER
	
	public Inventario getInventario() {
		return this.inventario;
	}
	
	public List<Cliente> getListaClienti(){
		return this.lista_clienti;
	}
	
	public List<OrdinePrenotato> getListaOrdiniPrenotati(){
		return this.ordini_prenotati;
	}

	public List<Farmaco> getInventarioCorrente(){
		return this.inventario_corrente;
	}
	
	public List<Farmaco> getFarmaciOrdineCorrente(){
		return this.farmaci_ordine_corrente;
	}
	
	public float getPrezzoOrdineCorrente() {
		return this.prezzo_ordine_corrente;
	}
	
	public Farmaco getFarmacoCorrente() {
		return this.farmaco_corrente;
	}
	
	public CartaCredito getCartaCreditoCorrente() {
		return this.carta_credito_corrente;
	}
	
	public Cliente getClienteAutenticato() {
		return this.cliente_autenticato;
	}
	
	public Cliente getClienteCorrente() {
		return this.cliente_corrente;
	}
	
	public Cliente getClienteAlBanco() {
		return this.cliente_albanco;
	}
	
	public List<String> getListaOrari(){
		return orari;
	}
	
	public OrdinePrenotato getOrdinePrenotatoCorrente() {
		return this.ordine_prenotato_corrente;
	}
	
	public OrdineConsegnato getOrdineSelezionato() {
		return this.ordine_selezionato_corrente;
	}
	
	public RegistroVendite getRegistroVendite() {
		return this.registro_vendite;
	}
	
	//Metodi SETTER
	
	public void setNuovoCliente(Cliente cliente) {
		this.lista_clienti.add(cliente);
	}
	
	public void setNuovoOrdine(OrdinePrenotato ordine) {
		this.ordini_prenotati.add(ordine);
	}
	
	public void setCancellaOrdine(OrdinePrenotato ordine) {
		this.ordini_prenotati.remove(ordine);
	}

	public void setClienteCorrente(Cliente nuovo_cliente) {
		this.cliente_corrente = nuovo_cliente;		
	}
	
	public void setClienteAlBanco(Cliente c) {
		this.cliente_albanco = c;		
	}
	
	public void setFarmacoCorrente(Farmaco farmaco_corrente) {
		this.farmaco_corrente = farmaco_corrente;
	}
	
	public void setCartaCreditoCorrente(CartaCredito carta_credito_corrente) {
		this.carta_credito_corrente = carta_credito_corrente;
	}
	
	public void setInventario(Farmaco farmaco) {
		this.inventario.setNuovoFarmaco(farmaco);
	}
	
	public void setClienteAutenticato(Cliente cliente_autenticato) {
		this.cliente_autenticato = cliente_autenticato;
	}
	
	public void setInventarioCorrente(List<Farmaco> inv){
		this.inventario_corrente = inv;
	}
	
	public void setFarmaciOrdineCorrente(Farmaco farmaco) {
		this.farmaci_ordine_corrente.add(farmaco);
	}
	
	public void setPrezzoOrdineCorrente(float prezzo_ordine_corrente) {
		this.prezzo_ordine_corrente = prezzo_ordine_corrente;
	}
	
	public void setListaOrari(String orario) {
		this.orari.remove(orario);
	}
	
	public void setOrdinePrenotatoCorrente(OrdinePrenotato prenotato) {
		this.ordine_prenotato_corrente = prenotato;
	}
	
	public void setOrdineSelezionato(OrdineConsegnato ordine_selezionato_corrente) {
		this.ordine_selezionato_corrente = ordine_selezionato_corrente;
	}
	
	public void setRegistroVendite(OrdineConsegnato oc) {
		this.registro_vendite.setOrdineConsegnato(oc);
	}
	
}
