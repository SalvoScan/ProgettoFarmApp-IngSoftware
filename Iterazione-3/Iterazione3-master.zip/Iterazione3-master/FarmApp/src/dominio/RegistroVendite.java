package dominio;

import java.util.*;

public class RegistroVendite {
	private List<OrdineConsegnato> ordini_consegnati;
	
	public RegistroVendite() {
		this.ordini_consegnati = new ArrayList<OrdineConsegnato>();
	}
	
	public List<OrdineConsegnato> getOrdineConsegnato(){
		return this.ordini_consegnati;
	}
	
	public void setOrdineConsegnato(OrdineConsegnato oc) {
		this.ordini_consegnati.add(oc);
	}
	
	public void stampaVendite() {
		for(OrdineConsegnato oc : ordini_consegnati)
			System.out.println(oc.toString());
	}
}
