package dominio;

import java.util.*;

public class Inventario {
	private List<Farmaco> lista_farmaci;
	private List<DescrizioneFarmaco> lista_descrizioni_farmaci;
	
	//Costruttore
	
	public Inventario() {
		this.lista_farmaci = new ArrayList<Farmaco>();
		this.lista_descrizioni_farmaci = new ArrayList<DescrizioneFarmaco>();
	}
	
	//Metodi GETTER
	
	public List<Farmaco> getListaFarmaci(){
		return this.lista_farmaci;
	}
	
	public List<DescrizioneFarmaco> getListaDescrizioniFarmaci(){
		return this.lista_descrizioni_farmaci;
	}
	
	//Metodi SETTER
	
	public void setNuovoFarmaco(Farmaco farmaco) {
		this.lista_farmaci.add(farmaco);
	}
	
	public void setListaFarmaci(List<Farmaco> lista_farmaci) {
		this.lista_farmaci = lista_farmaci;
	}
	
	public void setNuovaDescrizioneFarmaco(DescrizioneFarmaco df) {
		this.lista_descrizioni_farmaci.add(df);
	}
	
	//Stampa la lista dei farmaci
	public void stampaListaFarmaci() {
		for(Farmaco f : this.lista_farmaci) {
			System.out.println(f.toString());
		}
	}
	
	//Stampa la lista delle descrizioni dei farmaci
	public void stampaListaDescrizioniFarmaci() {
		for(DescrizioneFarmaco df : this.lista_descrizioni_farmaci) {
			System.out.println(df.toString());
		} 
	}
	
}
