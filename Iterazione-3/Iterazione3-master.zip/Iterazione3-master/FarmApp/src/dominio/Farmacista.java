package dominio;

public class Farmacista {
	private int id;
	private String email;
	private String password;
	
	public Farmacista(int id, String email, String password) {
		
		this.id = id;
		this.email = email;
		this.password = password;
	}
	
	//METODI GETTER

	public int getId() {
		return id;
	}

	public String getPassword() {
		return password;
	}
	

	public String getEmail() {
		return email;
	}

	
	//METODI SETTER

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPassword(String password) {
		this.password = password;
	};
	
	public void setId(int id) {
		this.id = id;
	}
	
	
	
}
