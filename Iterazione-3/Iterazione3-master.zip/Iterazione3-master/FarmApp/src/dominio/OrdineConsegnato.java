package dominio;

import java.util.Date;
import java.util.List;

public class OrdineConsegnato extends OrdinePrenotato{
	private int metodo;

	public OrdineConsegnato(OrdinePrenotato ordine) {
		super(ordine);
	}
	
	public int getMetodo() {
		return metodo;
	}
	
	public void setMetodo(int metodo) {
		this.metodo = metodo;
	}
	
}
