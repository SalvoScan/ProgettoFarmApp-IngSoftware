package dominio;

import java.util.Date;
import java.util.List;

public class OrdineConsulenza extends Ordine{
	public OrdineConsulenza(int cod_ordine, float prezzo_consulenza, Date orario_ordine, Date orario_ritiro, List<Farmaco> farmaci_ordinati) {
		super(cod_ordine, prezzo_consulenza, orario_ordine, orario_ritiro, null);
	}
}
