package dominio;

import java.util.*;

public class DescrizioneFarmaco {
	private String nome;
	private boolean prescrizione;
	private String sintomi;
	private String effetti_collaterali;
	private float prezzo_farmaco;
	private String num_serie;
	
	public DescrizioneFarmaco(String nome, boolean prescrizione, String sintomi, String effetti_collaterali, float prezzo_farmaco, String num_serie) {
		this.nome = nome;
		this.prescrizione = prescrizione;
		this.sintomi = sintomi;
		this.effetti_collaterali = effetti_collaterali;
		this.prezzo_farmaco = prezzo_farmaco;
		this.num_serie = num_serie;
	}
	
	//Metodi GETTER
	
	public String getNome() {
		return this.nome;
	}
	
	public String getNumSerie() {
		return this.num_serie;
	}
	
	public boolean getPrescrizione() {
		return this.prescrizione;
	}
	
	public String getSintomi() {
		return this.sintomi;
	}
	
	public String getEffettiCollaterali() {
		return this.effetti_collaterali;
	}
	
	public float getPrezzoFarmaco() {
		return this.prezzo_farmaco;
	}

	
	
	//Metodi SETTER
	
	public void setNome(String n) {
		this.nome = n;
	}
	
	public void setPrescrizione(boolean p) {
		this.prescrizione = p;
	}
	
	public void setSintomi(String s) {
		this.sintomi = s;
	}
	
	public void setEffettiCollaterali(String ec) {
		this.effetti_collaterali = ec;
	}
	
	public void setPrezzoFarmaco(float pf) {
		this.prezzo_farmaco = pf;
	}
	
	public void setNumSerie(String num_serie) {
		this.num_serie = num_serie;
	}
	
	//Metodo toString
	
	public String toString() {
		String s1 = "Descrizione Farmaco\n";
		String s2 = "Nome : " + nome + "\n"+ "Prescrizione : " + prescrizione + "\n" + "Sintomi : " + sintomi + "\n" + "Effetti collaterali : "
				+ effetti_collaterali + "\n" + "Prezzo : " + prezzo_farmaco + "\n";
		String s = s1 + s2;
			
		return s;
	}
	
}
