package Test;

import static org.junit.jupiter.api.Assertions.*;
import java.util.List;
import dominio.*;
import org.junit.jupiter.api.Test;

class TestAggiungiFarmacoOrdine {
	FarmApp fapp = new FarmApp();
	Inventario inv = new Inventario();

	@Test
	void Test() throws Exception{
		DescrizioneFarmaco descf = new DescrizioneFarmaco("vivinc", false, "mal di testa", "morte", 20, "12345");
		Farmaco farmaco = new Farmaco("12345", 3, descf);
		System.out.println(farmaco);
		inv.setNuovoFarmaco(farmaco);
		String num_serie = "12345";
		String s_quantita = "2";
		int quantita = Integer.parseInt(s_quantita);
		List<Farmaco> farmaci =  inv.getListaFarmaci();
		for (Farmaco f: farmaci){
			if(num_serie.equals(f.getNumSerie())) {
				Farmaco farmaco_corrente = new Farmaco(num_serie, quantita, descf);
				fapp.setFarmaciOrdineCorrente(farmaco_corrente);
				assertEquals(num_serie, farmaco_corrente.getNumSerie());
			}
		}
	}
}
