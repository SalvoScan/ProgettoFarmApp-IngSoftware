package dominio;

import java.util.*;

public class Farmaco {
	private String num_serie;
	private int quantita;
	private DescrizioneFarmaco descrizione_farmaco;
	
	//Costruttore
	
	public Farmaco(String num_serie, int quantita, DescrizioneFarmaco descrizione_farmaco) {
		this.num_serie = num_serie;
		this.quantita = quantita;
		this.descrizione_farmaco = descrizione_farmaco;
	}
	
	//Metodi GETTER
	
	public String getNumSerie() {
		return this.num_serie;
	}
	
	public int getQuantita() {
		return this.quantita;
	}
	
	public DescrizioneFarmaco getDescrizioneFarmaco() {
		return this.descrizione_farmaco;
	}
	
	//Metodi SETTER

	public void setNumSerie(String ns) {
		this.num_serie = ns;
	}
	
	public void setQuantita(int q) {
		this.quantita = q;
	}
	
	//Metodo toString
	
	public String toString() {
		String s1 = "INFO FARMACO\n";
		String s2 = "Nome : " + getDescrizioneFarmaco().getNome() + "\n" + "Numero di Serie : "+getNumSerie()+"\n"+
		"Quantita : "+getQuantita();
		String s = s1 + s2;
		
		return s;
	}
	
}
