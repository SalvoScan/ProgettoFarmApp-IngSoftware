package dominio;

public class Cliente {
	private int id;
	private String email;
	private String password;
	private Account a;
	/*dovrebbe avere una lista ordini*/
	
	//COSTRUTTORE
	public Cliente(String email, String password, Account a) {
		this.email = email;
		this.password = password;
		this.a = a;
	}

	//METODI GETTER

	public int getId() {
		return id;
	}

	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}
	
	public Account getAccount() {
		return a;
	}
	
	//METODI SETTER

	public void setEmail(String email) {
		this.email = email;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setAccount(Account a) {
		this.a = a;
	}

	@Override
	public String toString() {
		return "Cliente id=" + id + "\n" + "email=" + email + "\n" + "password=" + password;
	}
	
	
	
	
}
