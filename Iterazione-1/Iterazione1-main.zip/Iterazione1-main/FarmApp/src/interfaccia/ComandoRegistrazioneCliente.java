package interfaccia;

import java.util.*;

import dominio.*;

public class ComandoRegistrazioneCliente implements Comando{
	public static final String codiceComando="1";
	public static final String descrizioneComando="Nuovo Account";
	
   	public String getCodiceComando() {
		return codiceComando;
	}
	
   	public String getDescrizioneComando() {
		return descrizioneComando;
	}

    public void esegui(FarmApp fapp) {
    	System.out.println("Inserisci il nome del cliente:");
		String nome = Parser.getInstance().read();
		System.out.println("Inserisci il cognome del cliente:");
		String cognome = Parser.getInstance().read();
		System.out.println("Inserisci la data di nascita del cliente:");
		String data_nascita = Parser.getInstance().read();
		System.out.println("Inserisci il codice fiscale del cliente:");
		String codice_fiscale = Parser.getInstance().read();
		// controllo codice fiscale
		List<Cliente> lista_clienti = fapp.getListaClienti();
		Boolean codice = false;
		while(codice == false) {
			for (Cliente c : lista_clienti) {
				if (codice_fiscale.equals(c.getAccount().getCodiceFiscale())) {
					System.out.println("Esiste gi� un cliente con questo codice fiscale" + "\n" + "Inserirne uno valido");
					codice_fiscale = Parser.getInstance().read();
				}
				else {
					  codice = true;
				}
			}
		}
		System.out.println("Inserisci l'indirizzo del cliente:");
		String indirizzo = Parser.getInstance().read();
   		System.out.println("Inserisci l'email:");
		String email = Parser.getInstance().read();
		System.out.println("Inserisci la password");
		String password = Parser.getInstance().read();
		
		Account nuovo_account = new Account(nome, cognome, data_nascita, codice_fiscale, indirizzo);
		System.out.println(nuovo_account + "\n");
		System.out.println("Premi 2 per confermare i tuoi dati o 1 per modificarli");
		Cliente nuovo_cliente = new Cliente(email, password, nuovo_account);
		fapp.setClienteCorrente(nuovo_cliente);
	}
}
