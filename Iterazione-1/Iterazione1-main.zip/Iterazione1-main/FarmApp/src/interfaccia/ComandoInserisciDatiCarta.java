package interfaccia;

import dominio.*;

import java.text.SimpleDateFormat;
import java.util.*;

public class ComandoInserisciDatiCarta implements Comando{
	public static final String codiceComando = "1";
	public static final String descrizioneComando = "Inserimento nuova carta di credito";
	
	public String getCodiceComando() {
		return this.codiceComando;
	}
	
	public String getDescrizioneComando() {
		return this.descrizioneComando;
	}
	
	public void esegui(FarmApp fapp) throws Exception{
		System.out.println("Inserisci Codice IBAN");
		String codice_IBAN = Parser.getInstance().read();
		long cod_IBAN = Long.parseLong(codice_IBAN);
		System.out.println("Inserisci scadenza carta di credito");
		System.out.println("Formato  ->  dd.MM.yyyy");
		//Formato Data Scadenza "hh:mm dd.MM.yyyy"
		String scadenza = Parser.getInstance().read();
		System.out.println("Inserisci Nome Intestatario");
		String nome_intestatario = Parser.getInstance().read();
		System.out.println("Inserisci Cognome Intestatario");
		String cognome_intestatario = Parser.getInstance().read();
		
		SimpleDateFormat formato_data = new SimpleDateFormat ("hh:mm dd.MM.yyyy");
		
		Date data_corrente = new Date();
		String data_corr = formato_data.format(data_corrente); //sulla data corrente viene applicato formato_data per avere il formato "hh:mm dd.MM.yyyy"
		
		String giorno_corrente = data_corr.substring(6, 8);
		int giorno_corr = Integer.parseInt(giorno_corrente);
		String giorno_scadenza = scadenza.substring(0, 2);
		int giorno_scad = Integer.parseInt(giorno_scadenza);
		
		String mese_corrente = data_corr.substring(9, 11);
		int mese_corr = Integer.parseInt(mese_corrente);
		String mese_scadenza = scadenza.substring(3, 5);
		int mese_scad = Integer.parseInt(mese_scadenza);
		
		String anno_corrente = data_corr.substring(12, 16);
		int anno_corr = Integer.parseInt(anno_corrente);
		String anno_scadenza = scadenza.substring(6, 10);
		int anno_scad = Integer.parseInt(anno_scadenza);
		
		//Controllo Validit� della Scadenza
		
		if(anno_scad > anno_corr) {
			//Carta Valida -> Anno valido
		}
		if(anno_scad < anno_corr) {
			//Carta Non Valida -> Anno non valido
			System.out.println("Carta non valida");
			return;
		}
		if(anno_scad == anno_corr) {
			if(mese_scad > mese_corr) {
				//Carta Valida -> Mese valido
			}
			if(mese_scad < mese_corr) {
				//Carta Non Valida -> Mese non valido
				System.out.println("Carta non valida");
				return;
			}
			if(mese_scad == mese_corr) {
				if(giorno_scad > giorno_corr) {
					//Carta Valida -> Giorno valido
				}
				if(giorno_scad <= giorno_corr) {
					//Carta Non Valida -> Giorno non valido
					System.out.println("Carta non valida");
					return;
				}
			}
		}
		List<Cliente> clienti = fapp.getListaClienti();
		
		//viene confrontato l'IBAN inserito con gli IBAN delle carte gi� registrate
		for(Cliente c : clienti) {
			if(c.getAccount().getCartaCredito() != null) {
				if(cod_IBAN == c.getAccount().getCartaCredito().getCodIBAN()) {
					//Carta gi� esistente
					System.out.println("Carta gi� esistente");
					return;
				}
			}
		}
		
		 
		//Bisogna controllare che il Cliente non abbia gi� una carta diversa da quella inserita
		Cliente c = fapp.getClienteAutenticato();
		
		if(c.getAccount().getCartaCredito() != null) {
			//Il Cliente possiede gi� una carta di credito
			System.out.println("Carta di credito gi� registrata");
			System.out.println("Selezionare operazione");
			System.out.println("0 -> Annullare Operazione Inserimento Corrente");
			System.out.println("1 -> Eliminare Carta e Registrare quella Inserita");
			String scelta = Parser.getInstance().read();
			int x = Integer.parseInt(scelta);
			if(x == 0) {
				System.out.println("Operazione Annullata");
				return;
			}
			if(x == 1) {
				System.out.println("Carta di Credito precedente eliminata");
				CartaCredito cc_eliminata = c.getAccount().getCartaCredito();
				cc_eliminata = null;
			}
		}
		 
		//A questo punto la carta pu� essere inserita 
		
		SimpleDateFormat formato_data2 = new SimpleDateFormat ("dd.MM.yyyy");
		
		Date sc = new Date();
		sc = formato_data2.parse(scadenza);
		
		CartaCredito cc = new CartaCredito(cod_IBAN, sc, nome_intestatario, cognome_intestatario);
		
		//Riepilogo INFO
		
		System.out.println(cc);
		
		fapp.setCartaCreditoCorrente(cc);
				
	}
	
	
}
