package interfaccia;

import dominio.FarmApp;

public interface Comando {
	
    public String getCodiceComando();
	
	public String getDescrizioneComando();
	
    public void esegui(FarmApp fapp)throws Exception;
}
