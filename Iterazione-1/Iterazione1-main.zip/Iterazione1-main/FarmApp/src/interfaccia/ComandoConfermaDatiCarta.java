package interfaccia;

import dominio.*;
import java.util.*;

public class ComandoConfermaDatiCarta implements Comando{
	public static final String codiceComando = "2";
	public static final String descrizioneComando = "Conferma carta di credito";
	
	public String getCodiceComando() {
		return this.codiceComando;
	}
	
	public String getDescrizioneComando() {
		return this.descrizioneComando;
	}
	
	public void esegui(FarmApp fapp) {
		Cliente cliente_autenticato = fapp.getClienteAutenticato();
		CartaCredito carta_credito_corrente = fapp.getCartaCreditoCorrente();
		
		Account account_cliente = cliente_autenticato.getAccount();
		
		//Viene associata la carta di credito corrente all'account del cliente
		
		account_cliente.setCartaCredito(carta_credito_corrente);
		
		System.out.println("Operazione Terminata");
		
	}
	
	
}