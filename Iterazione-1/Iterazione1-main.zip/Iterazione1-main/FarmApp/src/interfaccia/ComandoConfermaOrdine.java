package interfaccia;
import java.text.*;
import java.util.*;
import dominio.*;

public class ComandoConfermaOrdine implements Comando{
	public static final String codiceComando = "3";
	public static final String descrizioneComando = "Conferma ordine";
	Ordine ordine;
	
	public String getCodiceComando() {
		return codiceComando;
	}

	public String getDescrizioneComando() {
		return descrizioneComando;
	}
	
	public void esegui(FarmApp farmapp) {
		GregorianCalendar gc = new GregorianCalendar();
		Date data_ordine = new Date();
		Date data_ritiro = new Date();
		long anno = gc.get(Calendar.YEAR);
		long mese = gc.get(Calendar.MONTH) + 1;
		long giorno = gc.get(Calendar.DATE);
		long ora_ordine = gc.get(Calendar.HOUR_OF_DAY);
	    long ora_ritiro = gc.get(Calendar.HOUR_OF_DAY) + 3;
		long min = gc.get(Calendar.MINUTE);
		
	    String s_data = String.valueOf(giorno) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + String.valueOf(ora_ordine) + ":" + String.valueOf(min);
	    String s_data1;
	    try{
	        data_ordine = new SimpleDateFormat("dd-MM-yyyy hh:mm").parse(s_data);
	        
	        if(ora_ordine >= 10 && ora_ordine <= 18){
	        	//Gestire orario 12 (viene visualizzato 00 in ora_ordine)
                s_data1 = String.valueOf(giorno) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + String.valueOf(ora_ritiro) + ":" + String.valueOf(min);
            }
	        
	        else if (ora_ordine >= 0 && ora_ordine <= 9){
                s_data1 = String.valueOf(giorno) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + "10:00";
            }
	        
	        else {
	        	gc.add((Calendar.DATE), 1);
                long domani = gc.get(Calendar.DATE);
                s_data1 = String.valueOf(domani) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + "10:00";
            }
	        
	        data_ritiro = new SimpleDateFormat("dd-MM-yyyy hh:mm").parse(s_data1);
	        System.out.println("La data e l'ora di ritiro e': " + data_ritiro);
	        System.out.println("Confermare tale orario? Y/N");
	        String scelta = Parser.getInstance().read();
	        if(scelta.equals("N")) {
	        	System.out.println("Scegli un orario tra quelli disponibili");
	        	List<String> orari = farmapp.getListaOrari();
	        	System.out.println(orari.toString());
	        	System.out.println("Scrivi l'orario desiderato (formato hh:mm):");
	        	String scelta_orario = Parser.getInstance().read();
	        	farmapp.setListaOrari(scelta_orario);
	        	gc.add((Calendar.DATE), 1);
	        	long domani = gc.get(Calendar.DATE);
	        	s_data1 = String.valueOf(domani) + "-" + String.valueOf(mese)+ "-" + String.valueOf(anno) + " " + scelta_orario;
	        	data_ritiro = new SimpleDateFormat("dd-MM-yyyy hh:mm").parse(s_data1);
	        }
	    } catch (ParseException e) {
	    System.out.println("Orario errato!");
	    return;
	    }
	    
		List<Ordine> ordini =  farmapp.getListaOrdini();
		List<Farmaco> farmaci_ordinati = farmapp.getFarmaciOrdineCorrente();
		float prezzo_finale = farmapp.getPrezzoOrdineCorrente();
		int cod_ordine = ordini.size() + 1;
		Ordine ordine_corrente = new Ordine(cod_ordine, prezzo_finale, data_ordine, data_ritiro, farmaci_ordinati);
		farmapp.setNuovoOrdine(ordine_corrente);
		farmapp.setPrezzoOrdineCorrente(0);
		//Far diminuire la quantit� dei farmaci ordinati
		System.out.println("Ordine confermato!");
	}
}
