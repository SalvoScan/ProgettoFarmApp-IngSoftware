package interfaccia;

import dominio.*;

public class GestioneProdottiConsole {
	public void start(FarmApp fapp) throws Exception {
		stampaBenvenuto();
		Comando comando = Parser.getInstance().getComando(ElencoComandi.GESTIONE_PRODOTTI);
		while (!comando.getCodiceComando().equals("0")) {
			comando.esegui(fapp);
			System.out.println();
			stampaBenvenuto();
			comando = Parser.getInstance().getComando(ElencoComandi.GESTIONE_PRODOTTI);
		}
		comando.esegui(fapp); 
	}

    private void stampaBenvenuto() {
        System.out.println("GESTIONE PRODOTTI");
		System.out.println(ElencoComandi.elencoTuttiComandi(ElencoComandi.GESTIONE_PRODOTTI));
		System.out.println("FAI LA TUA SCELTA");
	}
}
