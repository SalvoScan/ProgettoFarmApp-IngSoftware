package interfaccia;

import dominio.FarmApp;

public class FarmAppConsole {
	public void start() throws Exception {
		FarmApp fapp = new FarmApp();
		stampaBenvenuto();
		Comando comando = Parser.getInstance().getComando(ElencoComandi.FarmApp);
		
		while (!comando.getCodiceComando().equals("0")) {
			comando.esegui(fapp);
			System.out.println();
			stampaBenvenuto();
			comando = Parser.getInstance().getComando(ElencoComandi.FarmApp);
		}
		comando.esegui(fapp); 
		System.out.println("ARRIVEDERCI");
	}

    private void stampaBenvenuto() {
        System.out.println("FARMAPP");
		System.out.println(ElencoComandi.elencoTuttiComandi(ElencoComandi.FarmApp));
		System.out.println("SCEGLI");
	}
}
