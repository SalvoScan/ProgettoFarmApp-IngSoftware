package interfaccia;

import dominio.FarmApp;

public class ComandoAssociaCartaCredito implements Comando{
	public static final String codiceComando="4";
	public static final String descrizioneComando="carta credito";
	
   	public String getCodiceComando() {
		return codiceComando;
	}
	
   	public String getDescrizioneComando() {
		return descrizioneComando;
	}

    public void esegui(FarmApp fapp) throws Exception {
		AssociazioneCartaConsole acc = new AssociazioneCartaConsole();
		acc.start(fapp);
	}
}
