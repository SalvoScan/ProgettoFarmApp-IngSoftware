package Test;

import static org.junit.jupiter.api.Assertions.*;

import dominio.*;
import interfaccia.*;

import org.junit.jupiter.api.Test;

class TestVendita {
	FarmApp fapp = new FarmApp();
	ComandoSelezionaPagamento csp = new ComandoSelezionaPagamento();
	OrdineConsegnato oc = new OrdineConsegnato(fapp.getClienteAutenticato().getOrdinePrenotato());
	ComandoConfermaPagamento cp = new ComandoConfermaPagamento();
	
	@Test
	void testSelezionaPagamento() {
		fapp.setClienteAlBanco(fapp.getClienteAutenticato());
		fapp.getClienteAlBanco().setOrdiniConsegnati(oc);
		
		csp.esegui(fapp);
		
		if(fapp.getClienteAlBanco().getOrdiniConsegnati().get(fapp.getClienteAlBanco().getOrdiniConsegnati().size() - 1).getMetodo() == 0) {
			assertEquals(0, fapp.getClienteAlBanco().getOrdiniConsegnati().get(fapp.getClienteAlBanco().getOrdiniConsegnati().size() - 1).getMetodo());
		}else {
			assertEquals(1, fapp.getClienteAlBanco().getOrdiniConsegnati().get(fapp.getClienteAlBanco().getOrdiniConsegnati().size() - 1).getMetodo());
		}
		
	}
	@Test
	void testConfrontaVendite() {
		fapp.setClienteAlBanco(fapp.getClienteAutenticato());
		fapp.getClienteAlBanco().setOrdiniConsegnati(oc);
		
		cp.esegui(fapp);
		
		OrdineConsegnato oc1 = fapp.getRegistroVendite().getOrdineConsegnato().get(0);
		OrdineConsegnato oc2 = fapp.getClienteAlBanco().getOrdiniConsegnati().get(fapp.getClienteAlBanco().getOrdiniConsegnati().size() - 1);
		
		assertEquals(oc1.getCodOrdine(), oc2.getCodOrdine());
		assertEquals(oc1.getIdCliente(), oc2.getIdCliente());
		assertEquals(true, oc1.getPagato());
		assertEquals(true, oc2.getPagato());
		assertEquals(oc1.getPrezzoOrdine(), oc2.getPrezzoOrdine());
	}

}
