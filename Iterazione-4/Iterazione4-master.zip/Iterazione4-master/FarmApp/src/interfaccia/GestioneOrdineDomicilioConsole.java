package interfaccia;

import dominio.FarmApp;

public class GestioneOrdineDomicilioConsole {
	public void start(FarmApp fapp) throws Exception {
		stampaBenvenuto();
		Comando comando = Parser.getInstance().getComando(ElencoComandi.GESTIONE_ORDINE_DOMICILIO);
		while (!comando.getCodiceComando().equals("0")) {
				comando.esegui(fapp);
				System.out.println();
				stampaBenvenuto();
				comando = Parser.getInstance().getComando(ElencoComandi.GESTIONE_ORDINE_DOMICILIO);
		}
		
		comando.esegui(fapp); 
	}

    private void stampaBenvenuto() {
        System.out.println("GESTIONE ORDINE DOMICILIO");
		System.out.println(ElencoComandi.elencoTuttiComandi(ElencoComandi.GESTIONE_ORDINE_DOMICILIO));
		System.out.println("FAI LA TUA SCELTA");
	}
}
