package interfaccia;

import java.util.Date;
import java.util.List;
import dominio.*;

public class ComandoConfermaOrdineDomicilio implements Comando {
	public static final String codiceComando = "3";
	public static final String descrizioneComando = "Conferma ordine";
	
	public String getCodiceComando() {
		return codiceComando;
	}

	public String getDescrizioneComando() {
		return descrizioneComando;
	}

	public void esegui(FarmApp fapp) {
		OrdinePrenotato opd = fapp.getOrdinePrenotatoDomicilio();
		OrdineConsegnato oc = new OrdineConsegnato(opd);
		//aggiungiamo un observer ad ordine consegnato e aggiungiamo l'ordine alla lista ordini del cliente
		oc.setMetodo(fapp.getMetodo());
		oc.addObserver(fapp.getRegistroVendite());
		oc.setOrarioRitiro(new Date());
		oc.setPagato(true);
		
		
		for (Cliente c : fapp.getListaClienti()) {
			if (c.getId() == fapp.getClienteAdomicilio().getId()) {
				c.setOrdiniConsegnati(oc);
				System.out.println("Vendita confermata!");
				fapp.getFattorino().getListaOrdiniDom().remove(opd);
				c.setOrdinePrenotato(null);
				return;
			}
		}
		
	}
}
