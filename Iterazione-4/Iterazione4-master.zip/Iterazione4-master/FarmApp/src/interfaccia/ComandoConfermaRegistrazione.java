package interfaccia;

import java.util.*;
import dominio.*;

public class ComandoConfermaRegistrazione implements Comando {

	public static final String codiceComando="2";
	public static final String descrizioneComando="Conferma Dati";
	
   	public String getCodiceComando() {
		return codiceComando;
	}
	
   	public String getDescrizioneComando() {
		return descrizioneComando;
	}
   	
   	public void esegui(FarmApp fapp) { //recupera il cliente corrente, assegna l'id e lo aggiunge alla lista dei clienti
   		Cliente cliente_corrente = fapp.getClienteCorrente();
   		Cliente nuovo_cliente = new Cliente(cliente_corrente.getEmail(), cliente_corrente.getPassword(), cliente_corrente.getAccount());
   		List<Cliente> lista_clienti = fapp.getListaClienti();
   		if(lista_clienti.isEmpty()) 
   			nuovo_cliente.setId(1);
   		else {
   			int id_cliente = lista_clienti.size() + 1;
   			nuovo_cliente.setId(id_cliente);
   		}
   		fapp.setNuovoCliente(nuovo_cliente);
   		System.out.println("Cliente registrato!");
   	}
}
