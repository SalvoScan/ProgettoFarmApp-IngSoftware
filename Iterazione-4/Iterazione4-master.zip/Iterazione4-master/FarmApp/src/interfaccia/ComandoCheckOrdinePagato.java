package interfaccia;

import java.util.List;
import dominio.*;

public class ComandoCheckOrdinePagato implements Comando {
	public static final String codiceComando = "2";
	public static final String descrizioneComando = "Verifica pagamento ordine";
	
	public String getCodiceComando() {
		return codiceComando;
	}

	public String getDescrizioneComando() {
		return descrizioneComando;
	}

	public void esegui(FarmApp fapp) {
		Cliente c = fapp.getClienteAdomicilio();
		
		OrdinePrenotato op = new OrdinePrenotato(c.getOrdinePrenotato());
		op.setIdCliente(c.getOrdinePrenotato().getIdCliente());
		// se l'ordine non � stato pagato con carta, il cliente paga in contanti e viene settato il metodo di pagamento
		if(!op.getPagato()) {
			op.setPagato(true);
			fapp.setMetodo(1);
			System.out.println("Ordine consegnato");
		}
		else {
			fapp.setMetodo(0);
			System.out.println("Ordine consegnato");
		}
		fapp.setOrdinePrenotatoDomicilio(op);
	}
}
