package interfaccia;

import dominio.FarmApp;

public class RegistroVenditeConsole {
	public void start(FarmApp fapp) throws Exception {
		stampaBenvenuto();
		Comando comando = Parser.getInstance().getComando(ElencoComandi.REGISTRO_VENDITE);
		while (!comando.getCodiceComando().equals("0")) {
			comando.esegui(fapp);
			System.out.println();
			stampaBenvenuto();
			comando = Parser.getInstance().getComando(ElencoComandi.REGISTRO_VENDITE);
		}
		comando.esegui(fapp); 
	}

    private void stampaBenvenuto() {
        System.out.println("REGISTRO VENDITE");
		System.out.println(ElencoComandi.elencoTuttiComandi(ElencoComandi.REGISTRO_VENDITE));
		System.out.println("FAI LA TUA SCELTA");
	}
}
