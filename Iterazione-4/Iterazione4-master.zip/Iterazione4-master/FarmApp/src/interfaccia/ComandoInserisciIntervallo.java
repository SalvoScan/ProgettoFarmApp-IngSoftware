package interfaccia;

import dominio.*;
import java.time.*;
import java.util.*;

public class ComandoInserisciIntervallo implements Comando {
	public static final String codiceComando = "1";
	public static final String descrizioneComando = "InserisciIntervallo";
	
	public String getCodiceComando() {
		return codiceComando;
	}
	
	public String getDescrizioneComando() {
		return descrizioneComando;
	}
	
	public void esegui(FarmApp fapp) {
		RegistroVendite registro = fapp.getRegistroVendite();
		
		
		System.out.println("Scegli il periodo da visualizzare\n"  + "0 --> ultimo mese\n" + "1 --> ultima settimana\n" + "2 --> Tutti\n");
		int scelta = Integer.parseInt(Parser.getInstance().read());
		LocalDate now = LocalDate.now();
		LocalDate weekStart = now.minusDays(now.getDayOfWeek().getValue()-1);
		LocalDate weekEnd = now;
		System.out.println(weekStart);
		System.out.println(weekEnd);
		LocalDate previousMonth = now.minusMonths(1);
		LocalDate monthStart = previousMonth.withDayOfMonth(1);
		LocalDate monthEnd = previousMonth.withDayOfMonth(previousMonth.getMonth().maxLength());
		
		Date inizio_mese = Date.from(monthStart.atStartOfDay(ZoneId.systemDefault()).toInstant());
		Date fine_mese = Date.from(monthEnd.atStartOfDay(ZoneId.systemDefault()).toInstant());
		Date inizio_settimana = Date.from(weekStart.atStartOfDay(ZoneId.systemDefault()).toInstant());
		Date fine_settimana = Date.from(weekEnd.atStartOfDay(ZoneId.systemDefault()).toInstant());
		
		switch(scelta) {
		case 0 :{ for(OrdineConsegnato oc : registro.getOrdineConsegnato()) {
						if(((oc.getOrdine().getOrarioOrdine().compareTo(inizio_mese))>= 0) && 
							((oc.getOrdine().getOrarioOrdine().compareTo(fine_mese))< 0)) {
						
							registro = ordiniPeriodo(fapp, oc, registro);
						}
					}
					System.out.println("Incasso totale nel periodo :  " + registro.getIncassoPeriodo() + "\n");
					System.out.println("Farmaci venduti nel periodo:\n");
					registro.stampaFarmaci();
					registro.setIncassoPeriodo((float) 0.0);
					break;
		}
			
		case 1 :{ for(OrdineConsegnato oc : registro.getOrdineConsegnato()) {
						if(oc.getOrdine().getOrarioOrdine().compareTo(inizio_settimana)>= 0 && 
						oc.getOrdine().getOrarioOrdine().compareTo(fine_settimana) < 0) {
							registro = ordiniPeriodo(fapp, oc, registro);
						}
					}
					System.out.println("Incasso totale nel periodo :  " + registro.getIncassoPeriodo() + "\n");
					System.out.println("Farmaci venduti nel periodo:\n");
					registro.stampaFarmaci();
					registro.setIncassoPeriodo((float) 0.0);
					break;
		}
		case 2 : for(OrdineConsegnato oc : registro.getOrdineConsegnato()) {
					registro = ordiniPeriodo(fapp, oc, registro);
				}
		
					System.out.println("Incasso totale nel periodo :  " + registro.getIncassoPeriodo() + "\n");
					System.out.println("Farmaci venduti nel periodo:\n");
					registro.stampaFarmaci();
					registro.setIncassoPeriodo((float) 0.0);
					break;
		}
}

public RegistroVendite ordiniPeriodo(FarmApp fapp, OrdineConsegnato oc, RegistroVendite rv) {
	List<Farmaco> farmaci_venduti = new ArrayList<Farmaco>();
	farmaci_venduti = rv.getFarmaciVenduti();
	float incasso = 0;
	for(Farmaco f: oc.getOrdine().getFarmaciOrdinati()) {
		if(farmaci_venduti.isEmpty()) {
			farmaci_venduti.add(f);
			}
		else {
			for(Farmaco fv : farmaci_venduti) {
				if(f.getNumSerie().equals(fv.getNumSerie())){
					fv.setQuantita(fv.getQuantita() + f.getQuantita());
				}
			}
		}
			incasso = rv.getIncassoPeriodo() +  oc.getOrdine().getPrezzoOrdine();
			rv.setListaFarmaci(farmaci_venduti);
			rv.setIncassoPeriodo(incasso);
			System.out.println(oc.toString() + "\n");
			return rv;
		}
			return rv;
	}
}
