package interfaccia;

import java.util.*;

import dominio.*;

public class ComandoStoricoOrdine implements Comando{
	public static final String codiceComando = "1";
	public static final String descrizioneComando = "Storico degli ordini effettuati";
	
	public String getCodiceComando() {
		return codiceComando;
	}
	
	public String getDescrizioneComando() {
		return descrizioneComando;
	}
	
	public void esegui(FarmApp farmapp) {
		Cliente cl_autenticato = farmapp.getClienteAutenticato();
		List<Farmaco> farmaci;
		List<OrdineConsegnato> storico_ordini = cl_autenticato.getOrdiniConsegnati();
		for (OrdineConsegnato oc : storico_ordini) {
			farmaci = oc.getFarmaciOrdinati();
			System.out.println(oc.getCodOrdine());
			for(Farmaco f: farmaci) {
				System.out.println(f.toString());
			}

		}
	}
}

