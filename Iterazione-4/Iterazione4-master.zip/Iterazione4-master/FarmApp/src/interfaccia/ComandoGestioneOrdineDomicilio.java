package interfaccia;

import dominio.FarmApp;

public class ComandoGestioneOrdineDomicilio implements Comando {
	public static final String codiceComando="10";
	public static final String descrizioneComando="Gestione ordine domicilio";
	
   	public String getCodiceComando() {
		return codiceComando;
	}
	
   	public String getDescrizioneComando() {
		return descrizioneComando;
	}

    public void esegui(FarmApp fapp) throws Exception {
    	GestioneOrdineDomicilioConsole god = new GestioneOrdineDomicilioConsole();
		god.start(fapp);
	}
}
