package interfaccia;

import dominio.*;

public class ComandoGestioneProdotti implements Comando {
	public static final String codiceComando="2";
	public static final String descrizioneComando="gestione prodotti";
	
   	public String getCodiceComando() {
		return codiceComando;
	}
	
   	public String getDescrizioneComando() {
		return descrizioneComando;
	}

    public void esegui(FarmApp fapp) throws Exception {
		GestioneProdottiConsole gpc = new GestioneProdottiConsole();
		gpc.start(fapp);
	}
}
