package dominio;

import java.util.*;
import java.util.List;

abstract class Decoratore implements OrdineInterfaccia{
	private Ordine ordine = new Ordine();
	private List<Farmaco> farmaci_ordinati = new ArrayList<>();
	
	public Decoratore(Ordine o) {
		this.ordine.setCodOrdine(o.getCodOrdine()); 
		this.ordine.setOrarioOrdine(o.getOrarioOrdine());
		this.ordine.setOrarioRitiro(o.getOrarioRitiro());
		this.ordine.setPrezzoOrdine(o.getPrezzoOrdine());
		for(Farmaco f : o.getFarmaciOrdinati()) {
			Farmaco nf = new Farmaco(f.getNumSerie(), f.getQuantita(), f.getDescrizioneFarmaco());
			this.farmaci_ordinati.add(nf);
		}
		this.ordine.setFarmaciOrdinati(farmaci_ordinati);
		
	}
	
	//METODI GETTER
	
	public int getCodOrdine() {
		return ordine.getCodOrdine();
	}
	
	public Date getOrarioOrdine() {
		return ordine.getOrarioRitiro();
	}
		
	public Date getOrarioRitiro() {
		return ordine.getOrarioRitiro();
	}
	
	public float getPrezzoOrdine() {
		return ordine.getPrezzoOrdine();
	}
	
	public List<Farmaco> getFarmaciOrdinati() {
		return ordine.getFarmaciOrdinati();
	}
	
	public Ordine getOrdine() {
		return ordine;
	}
	
	
	//METODI SETTER

	public void setPrezzoOrdine(float po) {
		ordine.setPrezzoOrdine(po); 
	}
	
	public void setCodOrdine(int co) {
		ordine.setCodOrdine(co);
	}	
	
	public void setOrarioOrdine(Date oo) {
		ordine.setOrarioOrdine(oo);
	}
	public void setOrarioRitiro(Date or) {
		ordine.setOrarioRitiro(or); 
	}
	
	public void setFarmaciOrdinati(List<Farmaco> farmaci_ordinati) {
		ordine.setFarmaciOrdinati(farmaci_ordinati); 
	}
	
	//Metodo toString
	
	public String toString() {
		return ordine.toString();
	} 
}
