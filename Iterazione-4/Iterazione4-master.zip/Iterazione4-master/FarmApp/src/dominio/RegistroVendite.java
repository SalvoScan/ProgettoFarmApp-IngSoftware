package dominio;

import java.util.*;

public class RegistroVendite implements ObserverInterfaccia{
	private List<OrdineConsegnato> ordini_consegnati;
	private List<Farmaco> farmaci_venduti;
	private float incasso_periodo = 0;
	private boolean observed_state;
	private OrdineConsegnato ordine;
	
	public RegistroVendite() {
		this.ordini_consegnati = new ArrayList<OrdineConsegnato>();
		this.farmaci_venduti = new ArrayList<Farmaco>();
	}
	
	public List<OrdineConsegnato> getOrdineConsegnato(){
		return this.ordini_consegnati;
	}
	
	public List<Farmaco> getFarmaciVenduti(){
		return this.farmaci_venduti;
	}
	
	public OrdineConsegnato getOrdineConsegnatoOb() {
		return this.ordine;
	}
	
	public float getIncassoPeriodo() {
		return incasso_periodo;
	}
	
	public void setIncassoPeriodo(Float in) {
		this.incasso_periodo = in;
	}
	
	public void setOrdineConsegnato(OrdineConsegnato oc) {
		this.ordini_consegnati.add(oc);
	}
	
	public void setListaFarmaci(List<Farmaco> farmaci) {
		this.farmaci_venduti = farmaci;
	}
	
	public void setOrdineConsegnatoOb(OrdineConsegnato oc) {
		this.ordine = oc;
	}
	
	public void stampaVendite() {
		for(OrdineConsegnato oc : ordini_consegnati)
			System.out.println(oc.toString());
	}
	
	public void stampaFarmaci() {
		for(Farmaco f : farmaci_venduti)
			System.out.println(f.getDescrizioneFarmaco().getNome() + ":" + f.getQuantita());
	}

	public void update(OrdineConsegnato ordine) { // crea oggetto
		observed_state = ordine.getPagato();
		if(observed_state) {
			OrdineConsegnato o = new OrdineConsegnato(ordine);
			this.ordini_consegnati.add(ordine);
		}
	}
}
