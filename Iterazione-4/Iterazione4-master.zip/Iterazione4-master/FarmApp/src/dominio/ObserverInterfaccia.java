package dominio;

public interface ObserverInterfaccia {
	public void update(OrdineConsegnato o);
}
