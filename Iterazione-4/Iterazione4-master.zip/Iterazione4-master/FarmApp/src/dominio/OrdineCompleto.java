package dominio;

import java.util.Date;
import java.util.List;

public class OrdineCompleto extends Ordine{ 

	public OrdineCompleto(int cod_ordine, float prezzo_ordine, Date orario_ordine, Date orario_ritiro,
			List<Farmaco> farmaci_ordinati) {
		super(cod_ordine, prezzo_ordine, orario_ordine, orario_ritiro, farmaci_ordinati);
		// TODO Auto-generated constructor stub
	}
}
