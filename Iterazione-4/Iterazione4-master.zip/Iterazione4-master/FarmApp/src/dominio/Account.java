package dominio;
/*contiene i dati relativi ad un cliente registrato sull'app*/

public class Account {
	/*nome del cliente*/
	private String nome;
	/*cognome del cliente*/
	private String cognome;
	/*data di nascita del cliente*/
	private String data_nascita;
	/*codice fiscale del cliente*/
	private String codice_fiscale;
	/*indirizzo del cliente*/
	private String indirizzo;
	/* carta di credito associata all'account*/
	private CartaCredito cc = null;
	
	/*
	 * Crea nuovo oggetto Account
	 */
	public Account(String nome, String cognome, String data_nascita, String codice_fiscale, String indirizzo) {
		this.nome = nome;
		this.cognome = cognome;
		this.data_nascita = data_nascita;
		this.codice_fiscale = codice_fiscale;
		this.indirizzo = indirizzo;
	}

	//METODI GETTER
	public String getNome() {
		return this.nome;
	}

	public String getCognome() {
		return this.cognome;
	}
	
	public String getDataNascita() {
		return this.data_nascita;
	}
	
	public String getCodiceFiscale() {
		return this.codice_fiscale;
	}

	public String getIndirizzo() {
		return this.indirizzo;
	}
	
	public CartaCredito getCartaCredito() {
		return this.cc;
	}
	
	//METODI SETTER

	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public void setDataNascita(String data_nascita) {
		this.data_nascita = data_nascita;
	}

	public void setCodiceFiscale(String codice_fiscale) {
		this.codice_fiscale = codice_fiscale;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	
	public void setCartaCredito(CartaCredito carta_credito) {
		this.cc = carta_credito;
	}

	@Override
	public String toString() {
		return "Riepilogo Account" +"\n" + "nome=" + nome + "\n" + "cognome=" + cognome +"\n" + "data_nascita=" +  data_nascita + "\n" + "codice_fiscale="
				+ codice_fiscale + "\n"+ "indirizzo=" + indirizzo;
	}
	
	
}
